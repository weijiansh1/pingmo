"""Small CPU end-to-end implementation check, not a controller benchmark."""
import argparse
import json
from pathlib import Path
import sys
import torch

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'pingmo_src'))
from src.aircraft.parameters import PChannelParameters
from src.teacher.ppo.trainer import train,PPOTrainingConfig


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',type=Path,default=ROOT/'runs/ppo_smoke_new')
    args=ap.parse_args()
    rows=[json.loads(s) for s in (ROOT/'pingmo_src/data/aircraft/generated/p_channel_library_iv_a_5000_v1/plants.jsonl').read_text().splitlines()]
    row=next(r for r in rows if r['plant_id']=='train_core-0000')
    keys=['l_fa','lambda_s','t_r','zeta_d','omega_d','r_omega','r_zeta','tau_p']
    params=PChannelParameters(**{k:row['parameters'][k] for k in keys})
    torch.set_num_threads(1)
    config=PPOTrainingConfig(total_rollouts=2,n_envs=32,epochs=1,minibatch=1024,
        amp=False,device='cpu',width=32,blocks=1,conv_width=4,critic_width=32,
        critic_blocks=1,log_every=1,checkpoint_every=1,seed=20261024)
    final=train(params,config,args.out,verbose=False)
    print(json.dumps({'output':str(args.out),'steps':final['steps'],
        'training_bank_rmse_deg_s':final['rmse_deg_s'],
        'scope':'Implementation smoke test; undertrained and not a performance result'},indent=2))


if __name__=='__main__': main()
