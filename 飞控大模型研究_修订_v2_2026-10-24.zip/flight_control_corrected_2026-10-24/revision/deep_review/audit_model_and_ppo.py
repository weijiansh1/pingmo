"""Reproduce model/PPO findings from frozen pre-fix source and the delivered bank."""
from collections import Counter
from dataclasses import replace
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np
from scipy import signal
from scipy.integrate import trapezoid
from threadpoolctl import threadpool_limits
import torch

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'pingmo_src'))
from src.aircraft.parameters import PChannelParameters
from src.aircraft.p_channel import PChannel, p_channel_polynomials
from src.aircraft.sampler import classify_iv_a_quality
from src.envs import batched_p_channel as B
from src.envs.roll_rate_commands import RollRateCommandProfile

KEYS = ['l_fa','lambda_s','t_r','zeta_d','omega_d','r_omega','r_zeta','tau_p']


def archived(name, relative):
    path = HERE/'archive'/relative
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def physical_sensitivity(parameters):
    """Exact continuous delayed bank-angle step response at t=1 s."""
    numerator, denominator = p_channel_polynomials(parameters)
    # Integrating roll rate cancels its explicit numerator zero at the origin.
    a,b,c,d = signal.tf2ss(numerator[:-1], denominator)
    duration = 1.0 - parameters.tau_p
    if duration <= 0:
        return 0.0
    _, bd, _, _, _ = signal.cont2discrete((a,b,c,d), duration, method='zoh')
    return abs(float(np.degrees((c@bd).item())))


def grid_sensitivity(parameters, dt=.001):
    channel = PChannel(parameters, dt)
    # PChannel.step returns the state before advancing: index 0 is t=0.
    values = [channel.step(1.0)[0] for _ in range(round(1/dt)+1)]
    return float(abs(np.degrees(trapezoid(values, dx=dt))))


def main():
    torch.set_num_threads(1)
    path=ROOT/'pingmo_src/data/aircraft/generated/p_channel_library_iv_a_5000_v1/plants.jsonl'
    rows=[json.loads(s) for s in path.read_text().splitlines()]
    mismatches=[]; continuous_changes=[]; differences=[]
    with threadpool_limits(limits=1):
        for row in rows:
            params=PChannelParameters(**{k:row['parameters'][k] for k in KEYS})
            assessment=classify_iv_a_quality(params,row['sensitivity_measured_deg_per_n'])
            if any(assessment[k]!=row[k] for k in assessment):
                mismatches.append(row['plant_id'])
            exact=physical_sensitivity(params)
            differences.append((exact/row['sensitivity_measured_deg_per_n']-1)*100)
            corrected=classify_iv_a_quality(params,exact)
            if corrected['sampling_bucket']!=row['sampling_bucket'] or corrected['gjb_level']!=row['gjb_level']:
                grid = grid_sensitivity(params)
                grid_assessment = classify_iv_a_quality(params, grid)
                continuous_changes.append({'plant_id':row['plant_id'],
                    'old_sensitivity':row['sensitivity_measured_deg_per_n'],'continuous_sensitivity':exact,
                    'aligned_grid_sensitivity':grid,'aligned_grid_bucket':grid_assessment['sampling_bucket'],
                    'aligned_grid_level':grid_assessment['gjb_level'],
                    'old_bucket':row['sampling_bucket'],'continuous_bucket':corrected['sampling_bucket'],
                    'old_level':row['gjb_level'],'continuous_level':corrected['gjb_level']})
    gains=archived('gain_before_deep_review','pingmo_src/src/aircraft/gain_calibration.py')
    sensitivity_examples=[]
    for row in rows[::500]:
        params=PChannelParameters(**{k:row['parameters'][k] for k in KEYS})
        sensitivity_examples.append({'plant_id':row['plant_id'],
            'archived_function':gains.sensitivity_1s_deg_per_n(params,dt=.001),
            'aligned_grid':grid_sensitivity(params),'continuous':physical_sensitivity(params)})
    net=archived('ppo_networks_before_deep_review','pingmo_src/src/teacher/ppo/networks.py')
    torch.manual_seed(20261024)
    actor=net.PPOTeacherActor(width=16,blocks=1,conv_width=4,initial_log_std=0.0).eval()
    obs=torch.zeros(10000,176);priv=torch.zeros(10000,12)
    ratio_checks={}
    for name,mean,logstd in [('mean0_std1',0.,0.),('mean095_default_std',.95,-2.)]:
        with torch.no_grad(),patch.object(actor,'forward',return_value=(torch.full((10000,1),mean),torch.full((10000,1),logstd))):
            action,old,_=actor.act(obs,priv)
            new,_,_=actor.evaluate(obs,priv,action)
        ratio=(new-old).exp();clipped=action.abs().squeeze(-1)>=1
        ratio_checks[name]={'n':10000,'clipped':int(clipped.sum()),
            'ratios_not_one':int(((ratio-1).abs()>1e-6).sum()),
            'ratio_median_clipped':float(ratio[clipped].median()),'ratio_max':float(ratio.max())}
    commands=B.build_command_set()
    reference_excursion={}
    for amplitude in [15.,31.]:
        command=RollRateCommandProfile('audit','step',amplitude_deg_s=amplitude,onset_s=1.,duration_s=8.)
        ref,_=B._second_order_reference(np.append(command.samples(.001),amplitude*math.pi/180),0,True)
        reference_excursion[str(amplitude)]=float(np.degrees(trapezoid(ref,dx=.001)))
    # Reproduce the reset boundary and the mismatch in evaluation timestamps.
    params=PChannelParameters(**{k:rows[0]['parameters'][k] for k in KEYS})
    env=B.BatchedRollRateEnv(params,1,commands=[commands[0]])
    before=None;returned=None
    for k in range(B.EPISODE_STEPS):
        before=env.state.clone()
        returned=env.step(torch.full((1,1),.1))
    boundary={'clock_after_final_step':int(env.t[0]),'state_after_final_step_is_reset':bool(torch.all(env.state==0)),
        'returned_last_output':float(returned[2][0]),'returned_observation_output':float(returned[0][0,2]*B.COMMAND_SCALE_RAD_S)}
    result={'library':{'file_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'n':len(rows),
        'split_counts':Counter(r['split'] for r in rows),'bucket_counts':Counter(r['sampling_bucket'] for r in rows),
        'labels_inconsistent_with_implemented_rules':mismatches,
        'unique_parameter_vectors':len({tuple(r['parameters'][k] for k in KEYS) for r in rows}),
        'open_loop_spiral_unstable':sum(r['parameters']['lambda_s']>0 for r in rows),
        'roll_time_constant_gt_8s':sum(r['parameters']['t_r']>8 for r in rows),
        'dutch_decay_time_constant_gt_8s':sum(1/(r['parameters']['zeta_d']*r['parameters']['omega_d'])>8 for r in rows),
        'raw_075s_oscillation_diagnostic_counts':Counter(str(r['raw_metrics']['rho_osc']) for r in rows),
        'raw_075s_settling_at_horizon_count':sum(r['raw_metrics']['settling_time_s']>=.748 for r in rows),
        'ood_reasons':Counter(s for r in rows if r['split']=='ood_test' for s in r['ood_reasons'])},
        'sensitivity':{'comparison':'exact continuous t=1 response versus stored 1 kHz calibration; includes time-grid and fractional-delay approximation',
            'relative_difference_percent_quantiles':dict(zip(['min','median','p95','max'],np.quantile(differences,[0,.5,.95,1]).tolist())),
            'continuous_grade_or_bucket_changes':continuous_changes,'grid_examples':sensitivity_examples},
        'ppo':{'synthetic_probability_ratio_checks':ratio_checks,'synthetic_not_historical_training_frequency':True,
            'final_step_reset':boundary,'training_bank_entries':len(commands),
            'training_bank_unique_commands':len({c.command_id for c in commands}),
            'family_entry_counts':Counter(c.kind for c in commands),
            'discount_time_constant_s':-B.DT_POLICY/math.log(.995),
            'gae_trace_time_constant_s':-B.DT_POLICY/math.log(.995*.95),
            'coefficient_per_step':{'tracking_normalized_squared':50*.02,'force_normalized_squared':50*.02*.02,'action_squared':50*.02}},
        'reference_integral_deg_by_step_amplitude':reference_excursion,
        'scope':'Algorithm/model consistency audit; no PPO performance improvement is claimed'}
    (HERE/'audit_metrics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    compact={**result,'library':{k:v for k,v in result['library'].items() if k!='raw_075s_oscillation_diagnostic_counts'}}
    print(json.dumps(compact,ensure_ascii=False,indent=2))


if __name__=='__main__': main()
