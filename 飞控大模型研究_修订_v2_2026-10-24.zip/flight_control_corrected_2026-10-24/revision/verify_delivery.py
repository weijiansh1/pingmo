"""Run focused regressions and validate the delivered manuscript and evidence."""
import hashlib
import importlib.metadata
import io
import json
import math
from pathlib import Path
import platform
import sys
import unittest
from urllib.parse import unquote, urlparse
import xml.etree.ElementTree as ET

from bs4 import BeautifulSoup
from PIL import Image
import markdown

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def main():
    checks = {}
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.discover(str(ROOT/'tests'))
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    (ROOT/'revision/test_output.txt').write_text(stream.getvalue(), encoding='utf-8')
    checks['regression_tests_passed'] = result.wasSuccessful()
    checks['regression_test_count'] = result.testsRun

    image_counts = {}
    for name in ['dhc6_report.html', 'dhc6_paper.html']:
        path = ROOT/'webpage'/name
        soup = BeautifulSoup(path.read_text(encoding='utf-8'), 'html.parser')
        missing = []
        for tag, attr in [('img','src'), ('a','href')]:
            for node in soup.find_all(tag):
                raw = node.get(attr, '')
                url = urlparse(raw)
                if url.scheme or url.netloc or not url.path:
                    continue
                if not (path.parent/unquote(url.path)).exists():
                    missing.append(raw)
        checks[name+'_local_links'] = not missing
        image_counts[name] = len(soup.find_all('img'))
        checks[name+'_24_images'] = image_counts[name] == 24
        checks[name+'_offline'] = not soup.find_all('script')
    checks['same_html_content'] = (ROOT/'webpage/dhc6_report.html').read_bytes() == (ROOT/'webpage/dhc6_paper.html').read_bytes()
    for relative in ['00_交付说明.md', '01_修订记录.md', '02_品模与强化学习深查.md',
                     'pingmo_src/src/teacher/ppo/README.md']:
        path = ROOT/relative
        soup = BeautifulSoup(markdown.markdown(path.read_text(encoding='utf-8')), 'html.parser')
        for link in soup.find_all('a'):
            url = urlparse(link.get('href', ''))
            if not url.scheme and not url.netloc and url.path:
                assert (path.parent/unquote(url.path)).exists(), (relative, url.path)
    checks['deep_review_and_delivery_document_links'] = True

    figures = read(ROOT/'revision/figure_manifest.json')
    for fig in figures:
        base = ROOT/'webpage/paper'/fig['name']
        ET.parse(base.with_suffix('.svg'))
        with Image.open(base.with_suffix('.png')) as im:
            assert list(im.size) == fig['png_pixels']
        assert base.with_suffix('.pdf').read_bytes().startswith(b'%PDF')
        for source, expected in fig['sources'].items():
            assert hashlib.sha256((ROOT/source).read_bytes()).hexdigest() == expected, source
    checks['figure_source_hashes_and_formats'] = True

    phase = ROOT/'experiments/gjb_tau_e_20261023/results_phase_aligned'
    case_counts = {b:len(read(phase/b/'fits.json')) for b in ['batch','batch_amp050','batch_amp200','batch_seed2']}
    checks['all_1440_phase_corrected_fits'] = sum(case_counts.values()) == 1440 and all(n == 360 for n in case_counts.values())
    for batch in case_counts:
        for row in read(phase/batch/'fits.json').values():
            assert row['gate'] or row['tau_e'] is None
    checks['failed_tau_values_are_null'] = True

    fair = read(ROOT/'revision/fair_comparison_summary.json')
    checks['58_training_and_metric_checks'] = fair['checks'] == {'total':58,'passed':58}
    data = ROOT/'experiments/sae_delay_20261023/results_corrected'
    checkpoints = list(data.glob('policies_strict_s[12]/*.pt'))
    checks['ten_retrained_policy_checkpoints'] = len(checkpoints) == 10
    protocol = read(ROOT/'revision/fair_comparison_protocol.json')
    executed = ROOT/'revision/archive/train_policy_executed.py'
    checks['executed_training_code_matches_protocol'] = hashlib.sha256(executed.read_bytes()).hexdigest() == protocol['code_sha256']
    pilot = ROOT/'experiments/gjb_tau_e_20261023/results_corrected/verification_v2'
    checks['new_frf_end_to_end_three_objects'] = len(list(pilot.glob('*__*.json'))) == 3
    for p in pilot.glob('*__*.json'):
        d = read(p)
        assert d['sample_alignment'] == 'u(t_k),p(t_k)'
        assert d['frf_method'] == 'joint_harmonic_least_squares_v2'

    deep = ROOT/'revision/deep_review'
    audit = read(deep/'audit_metrics.json')
    bank = ROOT/'pingmo_src/data/aircraft/generated/p_channel_library_iv_a_5000_v1'
    bank_sha = hashlib.sha256((bank/'plants.jsonl').read_bytes()).hexdigest()
    overlay = read(bank/'quality_label_review.json')
    checks['original_5000_object_bank_preserved'] = (
        bank_sha == audit['library']['file_sha256'] == overlay['original_bank_sha256']
        and audit['library']['n'] == audit['library']['unique_parameter_vectors'] == 5000
        and audit['library']['labels_inconsistent_with_implemented_rules'] == [])
    changes = audit['sensitivity']['continuous_grade_or_bucket_changes']
    checks['two_sensitivity_boundary_corrections_recorded'] = (
        changes == overlay['corrected_boundary_cases']
        and [(r['plant_id'], r['aligned_grid_bucket']) for r in changes]
            == [('train_core-0717', 'L2'), ('train_core-1081', 'OOD')]
        and all(abs(r['aligned_grid_sensitivity']-r['continuous_sensitivity']) < 3e-6
                for r in changes))
    old_hashes = read(deep/'source_before.json')
    for source, expected in old_hashes.items():
        assert hashlib.sha256((deep/'archive'/source).read_bytes()).hexdigest() == expected
    checks['deep_review_archived_source_hashes'] = True
    smoke = deep/'ppo_smoke_train_core_0000'
    smoke_protocol = read(smoke/'protocol.json')
    smoke_summary = read(smoke/'summary.json')
    smoke_logs = [json.loads(line) for line in (smoke/'train_log.jsonl').read_text().splitlines()]
    for name, expected in smoke_protocol['source_sha256'].items():
        assert hashlib.sha256((deep/'ppo_smoke_executed'/f'{name}.py').read_bytes()).hexdigest() == expected
    checks['ppo_smoke_executed_sources_match_protocol'] = True
    checks['ppo_smoke_two_rollouts_25600_transitions'] = (
        len(smoke_logs) == smoke_summary['rollouts'] == 2
        and smoke_logs[-1] == smoke_summary['final']
        and smoke_logs[-1]['steps'] == 25600
        and smoke_protocol['episode_end_mode'] == 'finite_horizon'
        and all(r['terminal_bootstrap_mean'] == 0 for r in smoke_logs)
        and all(r['evaluation_alignment'] == 'same_time' for r in smoke_logs))
    diagnostic_keys = ['policy_loss','value_loss','entropy','approx_kl',
        'clip_fraction','grad_norm','action_clip_fraction','mean_reward','rmse_deg_s']
    checks['ppo_smoke_finite_diagnostics_and_saved_weights'] = (
        all(math.isfinite(r[k]) for r in smoke_logs for k in diagnostic_keys)
        and len(smoke_logs[-1]['per_command']) == 30
        and all((smoke/name).is_file() for name in ['checkpoint.pt','best_monitor_checkpoint.pt',
            'checkpoint_rollout_0001.pt','checkpoint_rollout_0002.pt']))

    changed = [ROOT/'pingmo_src/src/envs/batched_p_channel.py',
        ROOT/'pingmo_src/src/aircraft/gain_calibration.py',
        ROOT/'pingmo_src/src/aircraft/sampler.py',
        ROOT/'pingmo_src/src/teacher/ppo/trainer.py',
        ROOT/'pingmo_src/src/teacher/ppo/networks.py',
        ROOT/'pingmo_src/src/benchmark/time_domain.py',
        ROOT/'pingmo_src/src/quality/modal_response.py',
        ROOT/'experiments/gjb_tau_e_20261023/tau_e.py',
        ROOT/'paper_source/dhc6_paper.py']
    changed += list((ROOT/'experiments/sae_delay_20261023').glob('*.py'))
    changed += list((ROOT/'revision').glob('*.py'))
    changed += list(deep.glob('*.py'))
    for path in changed:
        compile(path.read_text(encoding='utf-8-sig'), str(path), 'exec')
    checks['current_python_sources_compile'] = True

    output = {'checks':checks, 'all_passed':all(v for k,v in checks.items()),
        'image_counts':image_counts, 'phase_corrected_case_counts':case_counts,
        'regressions':{'run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors)},
        'environment':{'python':platform.python_version(), **{
            name:importlib.metadata.version(name) for name in ['numpy','scipy','torch','matplotlib','Pillow','Markdown','beautifulsoup4']}}}
    (ROOT/'revision/verification.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(output,ensure_ascii=False,indent=2))
    if not output['all_passed']:
        print(stream.getvalue())
        sys.exit(1)


if __name__ == '__main__':
    main()
