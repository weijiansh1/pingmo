# PPO 实现及证据范围（修订 v2）

从交付包根目录运行小规模实现检查：

```bash
python revision/deep_review/run_ppo_smoke.py --out runs/ppo_smoke_new
```

完整训练可通过 `PPOTrainingConfig` 与 `train(parameters, config, output)` 设置预算，输出须用新目录。不要将默认训练预算或小规模检查认作原稿 49 个教师的复现结果。

- `actor.act()` 随机模式返回未裁剪高斯样本 u 及 log_prob(u)；buffer 保存 u，更新继续计算 log_prob(u)。环境执行 clip(u,−1,1)。确定性均值执行不变。
- `reference_mode="fixed"` 默认使用公共参考；`legacy_plant` 保留对象相关参考。
- `episode_end_mode="finite_horizon"` 默认定义 8 s 有限任务，终点 bootstrap=0。`legacy_reset` 表示旧重置状态继续估值目标，并不是时间截断。持续任务截断需保留重置前末状态，当前没有实现该模式。
- `evaluation_alignment="same_time"` 默认在 2.00–7.98 s 比较同一时刻参考与输出；`legacy_interval` 保留旧比较口径。
- `evaluate()` 是训练指令库上的确定性 monitor；30 个加权条目仅含 9 条独立指令。兼容字段 `eval_commands`、`eval_envs_per_command` 不选择该指令库，协议明确记录这一点。
- 奖励保持区间参考代价 p_ref(t_k)−p(t_k+20 ms)，与同一时刻的报告指标含义不同。dt=20 ms 时系数为 −[e_norm²+0.02 F_norm²+a²]，a 为裁剪后的力速率动作。
- `best_monitor_checkpoint.pt` 按训练库 RMSE 选择，不能称独立测试最优。`protocol.json` 记录配置、对象、指令和源码哈希；日志包含 PPO 更新诊断。GPU AMP 加入梯度缩放，本轮 CPU 检查未验证 GPU 性能。

完整结果和限制见根目录 [品模与强化学习深查](../../../../02_品模与强化学习深查.md)。既有小规模检查记录在 `revision/deep_review/ppo_smoke_train_core_0000/`，共 25,600 次转移，训练库 RMSE 20.22 deg/s，未达控制门限。不能将程序检查通过表述为性能改善，也不能用新代码认证缺少源码版本的旧教师结果。
