"""Invariants for likelihood ratios, episode boundaries and physical timestamps."""
import math
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np
import torch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'pingmo_src'))
from src.aircraft.parameters import PChannelParameters
from src.aircraft.gain_calibration import sensitivity_1s_deg_per_n
from src.envs import batched_p_channel as B
from src.teacher.ppo.networks import PPOTeacherActor
from src.teacher.ppo import trainer as T

torch.set_num_threads(1)


class ModelPPO(unittest.TestCase):
    def params(self):
        # Pole/zero cancellation gives p(s)/F(s)=s/(s+1)^2.
        return PChannelParameters(1.,-1.,1.,.5,1.,1.,1.,0.)

    def test_one_second_sensitivity_matches_analytic_response(self):
        expected=np.degrees(1-2/math.e)
        self.assertAlmostEqual(sensitivity_1s_deg_per_n(self.params(),dt=.001),expected,delta=1e-5)

    def test_zero_transport_delay_has_no_extra_sample(self):
        batch=B.build_plant_batch(self.params(),B.build_command_set()[:1])
        self.assertEqual(batch.delay_len,1)

    def test_unchanged_policy_ratio_is_one_even_when_actions_saturate(self):
        actor=PPOTeacherActor(width=16,blocks=1,conv_width=4)
        x=torch.zeros(2048,176);p=torch.zeros(2048,12)
        torch.manual_seed(0)
        with torch.no_grad(),patch.object(actor,'forward',return_value=(torch.full((2048,1),.95),torch.full((2048,1),-2.))):
            actions,old,_=actor.act(x,p)
            new,_,_=actor.evaluate(x,p,actions)
        self.assertGreater(int((actions.abs()>1).sum()),0)
        torch.testing.assert_close((new-old).exp(),torch.ones_like(old),rtol=0,atol=0)

    def test_environment_still_bounds_physical_actions(self):
        a=B.BatchedRollRateEnv(self.params(),1,commands=B.build_command_set()[:1])
        b=B.BatchedRollRateEnv(self.params(),1,commands=B.build_command_set()[:1])
        out_a=a.step(torch.tensor([[3.0]]));out_b=b.step(torch.tensor([[1.0]]))
        for x,y in zip(out_a,out_b): torch.testing.assert_close(x,y,rtol=0,atol=0)

    def test_finite_horizon_never_bootstraps_reset_state(self):
        class Env:
            n_envs=2;device=torch.device('cpu')
        def forbidden(*args): raise AssertionError('must not evaluate reset state')
        boot=T._rollout_bootstrap(forbidden,Env(),'finite_horizon')
        _,returns=T._gae(torch.zeros(3,2),torch.ones(3,2),boot,1.,1.)
        torch.testing.assert_close(returns,torch.zeros_like(returns),rtol=0,atol=0)

    def test_true_truncation_is_not_silently_treated_as_reset(self):
        with self.assertRaises(ValueError): T._rollout_bootstrap(None,None,'truncation')

    def test_monitor_compares_reference_and_response_at_same_time(self):
        class Actor(torch.nn.Module):
            def act(self,*args,**kwargs): return torch.zeros(1,1),None,None
        class Env:
            n_envs=1;n_cmd=1;device=torch.device('cpu')
            def reset(self): self.t=torch.zeros(1,dtype=torch.long);self.requested=torch.zeros(1)
            @property
            def reference(self): return self.t*.02
            def observation(self): return torch.zeros(1,176)
            def actor_privileged(self): return torch.zeros(1,12)
            def step(self,a):
                self.t+=1
                return self.observation(),torch.zeros(1),self.reference.clone()
        cfg=T.PPOTrainingConfig(amp=False,device='cpu')
        aligned=T.evaluate(Actor(),Env(),cfg)
        self.assertEqual(aligned['rmse_deg_s'],0.)
        cfg.evaluation_alignment='legacy_interval'
        legacy=T.evaluate(Actor(),Env(),cfg)
        self.assertAlmostEqual(legacy['rmse_deg_s'],np.degrees(.02),places=4)


if __name__=='__main__': unittest.main(verbosity=2)
