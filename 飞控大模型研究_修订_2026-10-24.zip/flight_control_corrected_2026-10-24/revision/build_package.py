"""Build a compact, checksummed delivery without regenerable large arrays."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT/'revision/package_manifest.json'


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def omission(relative):
    if '__pycache__' in relative.parts or relative.suffix in {'.pyc','.pyo'}:
        return 'Python cache'
    parts = relative.parts
    if len(parts) > 3 and parts[:2] == ('experiments','sae_delay_20261023') and parts[2] in {'replay_legacy','results_corrected'}:
        if parts[3] in {'dataset','plants'}:
            return 'Regenerable windows or per-plant arrays; see experiment README'
        if parts[3] == 'features' and relative.suffix == '.npy' and relative.name != 'pca16_components.npy':
            return 'Regenerable feature arrays; fitted PCA components and standardizer retained'
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path, default=ROOT.parent/'飞控大模型研究_修订_2026-10-24.zip')
    args = ap.parse_args()
    if args.output.exists():
        raise FileExistsError(f'Choose a new output archive: {args.output}')
    report = json.loads((ROOT/'revision/verification.json').read_text())
    if not report['all_passed']:
        raise RuntimeError('Delivery verification must pass before packaging')
    included, omitted = [], []
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or path == MANIFEST:
            continue
        rel = path.relative_to(ROOT)
        reason = omission(rel)
        if reason:
            omitted.append({'path':rel.as_posix(),'bytes':path.stat().st_size,'reason':reason})
        else:
            included.append({'path':rel.as_posix(),'bytes':path.stat().st_size,'sha256':digest(path)})
    original = ROOT.parent/'飞控大模型研究_交付_2026-10-24.zip'
    record = {'format_version':1,'root_directory':ROOT.name,
        'scope':'Code, weights, original MAT records, protocols, results and figures; large reproducible arrays excluded',
        'checksum_scope':'All included files except this self-describing manifest',
        'original_archive_sha256':digest(original) if original.is_file() else None,
        'included_files':included,'omitted_files':omitted,
        'included_bytes_excluding_manifest':sum(r['bytes'] for r in included),
        'omitted_bytes':sum(r['bytes'] for r in omitted)}
    MANIFEST.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(args.output,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for item in included:
            archive.write(ROOT/item['path'],f"{ROOT.name}/{item['path']}")
        archive.write(MANIFEST,f'{ROOT.name}/revision/package_manifest.json')
    with zipfile.ZipFile(args.output) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f'CRC failure: {bad}')
    checksum = digest(args.output)
    args.output.with_suffix('.zip.sha256').write_text(f'{checksum}  {args.output.name}\n',encoding='utf-8')
    print(json.dumps({'archive':str(args.output),'bytes':args.output.stat().st_size,
        'files':len(included)+1,'omitted_files':len(omitted),'sha256':checksum,'crc_check':'passed'},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
