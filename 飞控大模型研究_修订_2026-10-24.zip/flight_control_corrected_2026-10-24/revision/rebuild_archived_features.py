"""Recompute omitted feature arrays using the archived, unchanged encoders."""
import argparse
import json
from pathlib import Path
import shutil
import sys

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
SAE = ROOT / "experiments/sae_delay_20261023"
sys.path.insert(0, str(SAE))
import train_policy as TP


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=Path, default=SAE / "replay_legacy")
    args = ap.parse_args()
    source, dest = SAE / "results_large", args.data
    torch.set_num_threads(4)
    hist = np.load(dest / "dataset/history.npy", mmap_mode="r")
    meta = json.loads((source / "features/meta.json").read_text())
    out = dest / "features"
    out.mkdir(exist_ok=True)
    for name in ("standardizer.npz", "pca16_components.npy"):
        shutil.copy2(source / "features" / name, out / name)
    shutil.copytree(source / "models", dest / "models", dirs_exist_ok=True)
    meta["training_scope"] = "all_train_core"
    meta["provenance"] = "Archived weights and standardizer; scope inferred from supplied training script, not retrained"
    for name in meta["models"]:
        model = TP.make_frontend(name, source).eval()
        z, zn = [], []
        with torch.no_grad():
            for start in range(0, len(hist), 8192):
                x = torch.from_numpy(np.array(hist[start:start + 8192]))
                z.append(model(x).numpy())
                zn.append(model(-x).numpy())
        np.save(out / f"{name}.npy", np.concatenate(z))
        np.save(out / f"{name}_neg.npy", np.concatenate(zn))
        print(f"rebuilt {name}", flush=True)
    (out / "meta.json").write_text(json.dumps(meta, indent=2))
    a = {r["plant_id"]: r for r in json.loads((source / "plants.json").read_text())}
    b = {r["plant_id"]: r for r in json.loads((dest / "plants.json").read_text())}
    checks = {"same_plant_ids": a.keys() == b.keys(), "max_abs_metric_diff": {}}
    for key in ("rmse_by_command", "peak_by_command", "tv_by_command"):
        checks["max_abs_metric_diff"][key] = max(abs(u-v) for i in a for u,v in zip(a[i][key],b[i][key]))
    def passed(r):
        return ((np.array(r["rmse_by_command"]) <= 1.5) &
                (np.array(r["peak_by_command"]) <= 5) & (np.array(r["tv_by_command"]) <= 12))
    checks["changed_pass_fail_episodes"] = sum(int(np.count_nonzero(passed(a[i]) != passed(b[i]))) for i in a)
    checks["interpretation"] = "Same cohort; small cross-platform floating-point differences retained"
    (ROOT / "revision/replay_validation.json").write_text(json.dumps(checks, indent=2))
    print(json.dumps(checks, indent=2))


if __name__ == "__main__":
    main()
