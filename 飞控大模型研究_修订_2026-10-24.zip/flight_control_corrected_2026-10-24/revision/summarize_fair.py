"""Check actual training provenance and reaggregate the new paired comparison."""
import json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'experiments/sae_delay_20261023/results_corrected'

def main():
    metas=json.loads((DATA/'plants.json').read_text())
    byid={m['plant_id']:m for m in metas}
    models={}
    checks=[]
    for seed in ['s1','s2']:
        directory=DATA/f'policies_strict_{seed}'
        protocol=json.loads((directory/'protocol.json').read_text())
        checks.extend([
            all(byid[i]['tau_p']<=.15 for i in protocol['train_plant_ids']),
            all(byid[i]['tau_p']<=.15 for i in protocol['dagger_plant_ids']),
            len(protocol['train_plant_ids'])==200,
            len(protocol['dagger_plant_ids'])==96,
            len(protocol['test_plant_ids'])==40,
            protocol['reference_mode']=='fixed',
            protocol['initialization']=='scratch',
        ])
        results=json.loads((directory/'policy_results.json').read_text())
        models[seed]=results
        for name,d in results.items():
            checks.append(len(d['dagger_rounds'])==2)
            checks.append(d['dagger_rounds'][1]['aggregated_windows']==2*d['dagger_rounds'][0]['new_windows'])
            checks.append(all(byid[row['plant_id']]['split']=='id_test' and byid[row['plant_id']]['tau_p']>.15 for row in d['rows']))
            triples=[x for row in d['rows'] for x in zip(row['metrics']['rmse'],row['metrics']['peak'],row['metrics']['tv'])]
            passed=sum(a<=1.5 and b<=5 and c<=12 for a,b,c in triples)
            checks.append(abs(passed/len(triples)-d['eval']['long']['pass_rate'])<1e-12)
    stats=json.loads((DATA/'sae_training.json').read_text())
    for model in stats['models'].values():
        checks.append(model['training_scope']=='tau_p_le_0.15')
        checks.append(all(byid[i]['tau_p']<=.15 and byid[i]['split']=='train_core' for i in model['training_plant_ids']))
    assert all(checks)
    out={'variants':{},'checks':{'total':len(checks),'passed':sum(checks)},
         'note':'Only policy seeds vary; frozen source-trained encoders are shared. Teacher pretraining exposure unknown.'}
    for name in models['s1']:
        out['variants'][name]={s:models[s][name]['eval']['long'] for s in ['s1','s2']}
        out['variants'][name]['parameters_trainable']=models['s1'][name]['parameters_trainable']
        out['variants'][name]['parameters_total']=models['s1'][name]['parameters_total']
    (ROOT/'revision/fair_comparison_summary.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))

if __name__=='__main__': main()
