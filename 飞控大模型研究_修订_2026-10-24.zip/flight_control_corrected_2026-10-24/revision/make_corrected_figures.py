"""Figures for the checked manuscript; source JSON and export metadata retained."""
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'webpage/paper'
BASE=ROOT/'experiments/sae_delay_20261023'
TAU=ROOT/'experiments/gjb_tau_e_20261023/results_phase_aligned'
BLUE='#0072B2'; ORANGE='#B65300'; GREEN='#007F60'; PURPLE='#885C99'; GRAY='#656565'
COLORS=[BLUE,ORANGE,GREEN,PURPLE,GRAY]
LABELS={'raw':'Raw history','raw_ft':'Raw history','pca16':'PCA-16','dense16':'Dense AE-16','topk4':'Top-k SAE','aux_topk4':'SAE auxiliary'}
MANIFEST=[]

def read(path): return json.loads(path.read_text())

def save(fig,name,sources,description):
    for fmt in ['svg','pdf','png']:
        fig.savefig(OUT/f'{name}.{fmt}',dpi=180,facecolor='white',transparent=False)
    png=Image.open(OUT/f'{name}.png')
    MANIFEST.append({'name':name,'description':description,'size_inches':fig.get_size_inches().tolist(),
        'png_pixels':list(png.size),'png_dpi':png.info.get('dpi'),
        'sources':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
        'publisher':'general research/web draft; no journal-specific compliance claim',
        'missing':'unassessable fits excluded from tau values and separately counted',
        'uncertainty':'Only reference-check difference panel has plant-cluster bootstrap 95% intervals; policy seeds are individual points'})
    plt.close(fig)

def clean(ax):
    ax.spines[['top','right']].set_visible(False)
    ax.grid(axis='y',alpha=.18)
    ax.set_axisbelow(True)

def good(fits,policy): return {r['plant_id']:r['tau_e'] for r in fits.values() if r['policy']==policy and r['gate']}

def main():
  with plt.rc_context({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':11,
                       'pdf.fonttype':42,'svg.fonttype':'path','axes.unicode_minus':False}):
    fig,ax=plt.subplots(figsize=(8.4,2.8),layout='constrained'); ax.set_axis_off()
    contents=[('Object pool','5,000 parameterized\nroll-channel plants'),('PPO teachers','49 attempted / 46 passed\n(archived report)'),('Shared students','tiny: 3,856 parameters\nsmall: 75,040 parameters'),('DHC-6 ARX','small: 2.913 → 0.595 deg/s\n8 adaptation states\n(archived report)')]
    for i,(title,body) in enumerate(contents):
        x=.015+i*.25
        ax.add_patch(FancyBboxPatch((x,.35),.22,.48,boxstyle='round,pad=0.008',facecolor='#F0F5F9',edgecolor=BLUE,transform=ax.transAxes))
        ax.text(x+.11,.74,title,ha='center',weight='bold',transform=ax.transAxes)
        ax.text(x+.11,.53,body,ha='center',va='center',fontsize=8.6,transform=ax.transAxes)
        if i<3: ax.annotate('',(x+.248,.59),(x+.223,.59),xycoords=ax.transAxes,arrowprops={'arrowstyle':'->','color':GRAY})
    ax.text(.5,.14,'Source compression and target adaptation use different model sizes.\nFull original main-run evidence is not included in the delivery.',ha='center',va='center',fontsize=9,transform=ax.transAxes)
    save(fig,'revised_pipeline',[ROOT/'revision/archive/dhc6_report_original.md'],'Method chain with archived-evidence status and distinct student sizes.')

    p=BASE/'replay_legacy/probe_episode.json';d=read(p)
    keys=['handcrafted_xcorr','raw_history','pca16','dense16','topk4','l1_3e-03','l1_3e-02']
    labels=['Cross-corr.','Raw','PCA','Dense AE','Top-k','L1 weak','L1 strong']
    fig,axs=plt.subplots(1,2,figsize=(8.4,3.5),layout='constrained')
    for i,(time,color,hatch) in enumerate([('1.2s',BLUE,''),('2.0s',ORANGE,'//')]):
        x=np.arange(len(keys))+(i-.5)*.35
        axs[0].bar(x,[d['probes'][time][k]['test_r2'] for k in keys],.34,label=time,color=color,hatch=hatch)
        axs[1].bar(x,[d['probes'][time][k]['test_mae_ms'] for k in keys],.34,label=time,color=color,hatch=hatch)
    for ax in axs:
        ax.set_xticks(np.arange(len(keys)),labels,rotation=35,ha='right');clean(ax)
        ax.legend(frameon=False)
    axs[0].set(ylabel='Test R²',ylim=(0,1.04),title='(a) Strict decision-time cutoff')
    axs[1].set(ylabel='Test MAE (ms)',ylim=(0,65),title='(b) 120 plants / 960 episodes')
    save(fig,'revised_probe',[p],'Strictly causal probe; latest available sample at decision time 1.2s is 1.16s.')

    p=BASE/'results_large/policies_all_dagger2/policy_results.json'; d=read(p)
    fig,ax=plt.subplots(figsize=(8.4,3.4),layout='constrained')
    for i,k in enumerate(['raw_ft','pca16','dense16','topk4','aux_topk4']):
        ax.bar(np.arange(3)+(i-2)*.15,[100*d[k]['eval'][b]['pass_rate'] for b in ['short','medium','long']],.145,color=COLORS[i],hatch=['','//','..','xx','\\\\'][i],label=LABELS[k])
    ax.set_xticks(range(3),['Short delay','Medium delay','Long delay']);ax.set(ylim=(0,105),ylabel='Episode pass rate (%)',title='Archived recipes: initialization / collection budgets differ')
    ax.legend(frameon=False,ncol=3,fontsize=8,loc='upper center',bbox_to_anchor=(.5,-.12));clean(ax)
    save(fig,'revised_archived_policies',[p],'Historical results; invalid source-only column removed.')

    p=TAU/'batch/fits.json';fits=read(p);summ=read(TAU/'batch/summary.json')
    fig,axs=plt.subplots(1,2,figsize=(8.4,3.7),layout='constrained')
    for k,color,marker in [('raw_ft',BLUE,'o'),('aux_topk4',ORANGE,'^')]:
        rows=[r for r in fits.values() if r['policy']==k and r['gate']]
        axs[0].scatter([r['tau_p'] for r in rows],[r['tau_e'] for r in rows],color=color,marker=marker,s=16,alpha=.75,label=f'{LABELS[k]} (n={len(rows)})')
    for y in [.1,.2,.25]: axs[0].axhline(y,color=GRAY,ls='--',lw=.8)
    axs[0].set(xlabel='Plant transport delay τp (s)',ylabel='Aligned LOES delay τe (s)',ylim=(0,.52),title='(a) Assessable cases only');axs[0].legend(frameon=False,fontsize=8);clean(axs[0])
    pol=['raw_ft','aux_topk4','topk4'];bottom=np.zeros(3)
    for level,label,color,hatch in [('level1','≤ 0.10 s','#8CBAB0',''),('level2','0.10–0.20 s','#E9C777','//'),('level3','0.20–0.25 s','#D98C64','..'),('exceeds_level3','> 0.25 s','#9B4D5B','xx'),('not_assessable','Not assessable','#D1D5DA','\\\\')]:
        v=np.array([summ[k]['not_assessable'] if level=='not_assessable' else summ[k]['levels'][level] for k in pol])
        axs[1].bar(range(3),v,bottom=bottom,color=color,hatch=hatch,edgecolor='white',label=label);bottom+=v
    axs[1].set_xticks(range(3),['Raw','SAE aux','Top-k']);axs[1].set(ylabel='Objects (all 120 retained)',ylim=(0,125),title='(b) Reference thresholds, not certification')
    axs[1].legend(frameon=False,fontsize=7,ncol=2,loc='upper center',bbox_to_anchor=(.5,-.10));clean(axs[1])
    save(fig,'revised_tau_e',[p,TAU/'batch/summary.json'],'Time-aligned refit, full denominator with unassessable objects.')

    batches=['batch_amp050','batch','batch_amp200']; allfits={b:read(TAU/b/'fits.json') for b in batches+['batch_seed2']}
    fig,axs=plt.subplots(1,2,figsize=(8.4,3.3),layout='constrained')
    for k,c,m in [('raw_ft',BLUE,'o'),('aux_topk4',ORANGE,'^'),('topk4',GRAY,'s')]:
        sets=[good(allfits[b],k) for b in batches];common=set(sets[0]).intersection(*map(set,sets[1:]))
        if common: axs[0].plot([.5,1,2],[np.median([s[i] for i in common]) for s in sets],color=c,marker=m,label=f'{LABELS[k]} (n={len(common)})')
        axs[1].plot([.5,1,2],[len(s) for s in sets],color=c,marker=m,label=LABELS[k])
    for ax in axs: ax.set_xlabel('Per-component amplitude (deg/s)');ax.set_xticks([.5,1,2]);clean(ax);ax.legend(frameon=False,fontsize=8)
    axs[0].set(ylabel='Median τe on common objects (s)',ylim=(0,.2),title='(a) Seed 1, common cohort')
    axs[1].set(ylabel='Assessable objects / 120',ylim=(-3,125),title='(b) All policies; Top-k remains unavailable')
    save(fig,'revised_tau_amplitude',[TAU/b/'fits.json' for b in batches],'Amplitude comparisons use a fixed intersection within each policy.')

    fig,axs=plt.subplots(1,2,figsize=(8.4,3.5),layout='constrained')
    for ax,k,c,m in zip(axs,['raw_ft','aux_topk4'],[BLUE,ORANGE],['o','^']):
        s1=good(allfits['batch'],k);s2=good(allfits['batch_seed2'],k);keys=sorted(set(s1)&set(s2))
        ax.scatter([s1[i] for i in keys],[s2[i] for i in keys],color=c,marker=m,s=18,alpha=.75)
        ax.plot([0,.5],[0,.5],'--',color=GRAY,lw=.8);ax.set(xlim=(0,.5),ylim=(0,.5),xlabel='Seed 1 τe (s)',ylabel='Seed 2 τe (s)',title=f'{LABELS[k]}: common n={len(keys)}');clean(ax)
    save(fig,'revised_tau_seed',[TAU/'batch/fits.json',TAU/'batch_seed2/fits.json'],'Two policy seeds at base amplitude only; Top-k has no jointly assessable values.')

    p=ROOT/'revision/reference_check/summary.json';d=read(p);groups=['all','short','medium','long']
    fig,axs=plt.subplots(1,2,figsize=(8.4,3.4),layout='constrained');x=np.arange(4)
    for offset,k,c,h,label in [(-.18,'legacy_plant',BLUE,'','Object-dependent reference'),(.18,'fixed',ORANGE,'//','Common reference')]:
        axs[0].bar(x+offset,[100*d[g][k]['pass_rate'] for g in groups],.35,color=c,hatch=h,label=label)
    axs[0].set(ylim=(0,100),ylabel='Episode pass rate (%)',title='(a) Frozen tiny, same target');axs[0].legend(frameon=False,fontsize=7,loc='upper center',bbox_to_anchor=(.5,-.12))
    y=np.array([100*d[g]['paired_pass_rate_delta_fixed_minus_legacy'] for g in groups]);limits=np.array([d[g]['bootstrap_95_interval'] for g in groups])*100
    axs[1].errorbar(x,y,yerr=[y-limits[:,0],limits[:,1]-y],fmt='o',color=BLUE,capsize=4)
    axs[1].axhline(0,color=GRAY,ls='--');axs[1].set(ylabel='Common minus object-dependent (pp)',ylim=(-1,10),title='(b) Plant-bootstrap 95% interval')
    for ax in axs: ax.set_xticks(x,['All','Short','Medium','Long']);clean(ax)
    save(fig,'revised_reference',[p],'Same frozen checkpoint and common target; bootstrap over 120 or 40 plants, not over independent episodes.')

    p=ROOT/'revision/fair_comparison_summary.json';d=read(p)['variants'];keys=list(d)
    fig,axs=plt.subplots(1,2,figsize=(8.4,3.7),layout='constrained')
    for offset,s,c,m in [(-.08,'s1',BLUE,'o'),(.08,'s2',ORANGE,'^')]:
        x=np.arange(5)+offset
        axs[0].scatter(x,[100*d[k][s]['pass_rate'] for k in keys],color=c,marker=m,label=f'Policy seed {s[-1]}',s=42)
        axs[1].scatter(x,[d[k][s]['rmse_median'] for k in keys],color=c,marker=m,label=f'Policy seed {s[-1]}',s=42)
    for ax in axs: ax.set_xticks(range(5),[LABELS[k] for k in keys],rotation=25,ha='right');clean(ax);ax.legend(frameon=False,fontsize=8)
    axs[0].set(ylim=(0,100),ylabel='Long-delay episode pass rate (%)',title='(a) 40 plants / 320 episodes per seed')
    axs[1].set(ylim=(0,1.2),ylabel='Median tracking RMSE (deg/s)',title='(b) Scratch students; source-only updates')
    save(fig,'revised_fair',[p],'Each trained policy seed is shown separately; shared frozen encoders, unequal trainable parameter counts disclosed in table.')
  (ROOT/'revision/figure_manifest.json').write_text(json.dumps(MANIFEST,indent=2))
  print(f'Wrote {len(MANIFEST)} figures in SVG/PDF/PNG with metadata')

if __name__=='__main__': main()
