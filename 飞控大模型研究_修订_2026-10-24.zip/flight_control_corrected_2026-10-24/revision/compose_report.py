"""Compose checked prose and tables from archived and newly verified evidence."""
from pathlib import Path
import json
import re
import statistics as stats

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'experiments/sae_delay_20261023'
TAU = ROOT / 'experiments/gjb_tau_e_20261023/results_phase_aligned'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def main():
    text = (ROOT / 'revision/archive/dhc6_report_original.md').read_text(encoding='utf-8')
    probe = read(BASE / 'replay_legacy/probe_episode.json')
    tau = read(TAU / 'summary_all.json')
    fair = read(ROOT / 'revision/fair_comparison_summary.json')
    ref = read(ROOT / 'revision/reference_check/summary.json')
    def replace(old, new):
        nonlocal text
        if old not in text:
            raise ValueError('Original passage not found: ' + old[:100])
        text = text.replace(old, new)
    def section(start, end, new):
        nonlocal text
        i, j = text.index(start), text.index(end, text.index(start))
        text = text[:i] + new.rstrip() + '\n\n' + text[j:]

    section('## 摘要', '## 2问题定义与控制对象', '''## 摘要

本文研究按飞行品质相关参数组织源域对象、训练专用教师并蒸馏统一滚转策略的流程。归档主线构造 5,000 个参数化对象，报告 49 个 PPO 教师中 46 个通过项目门限，及 tiny（3,856 参数）和 small（75,040 参数）两种学生。tiny 相对教师的 RMSE 中位倍数为同分布 1.28、四对象留出 1.68；small 为 1.34、1.41。上述结果存在精度损失，不能证明容量无关或把差距归因于特权信息。300 个同分布对象的 ±1/±31 deg/s 通过率为 99.7%/60.3%，500 个 OOD 对象为 86.8%/27.6%。DHC-6 仿真辨识对象上的 small 适配组中位误差由 2.913 降至 0.595 deg/s，留出组由 2.662 降至 2.148 deg/s；这些主线数值保留为归档报告值，完整原始证据未随包提供。

本次修订核对并重建了 510 对象的 SAE 数据，修复学生参考对真实时延的依赖、跨时延更新中的样本回流，以及探针和频响评价的时间问题。在严格 1.2 s 截止下，互相关时延探针 R²=0.984、MAE=5.6 ms。对归档频响修正 20 ms 时间偏差并重新拟合后，raw/SAE-aux 的可评对象分别为 73/101 个，中位等效延迟为 0.093/0.125 s，Top-k 为 0/120 可评。另补固定公共参考对照和两种策略种子的训练范围受限实验。结论限定于所述仿真对象、输入条件与项目门限，不等同于实飞验证或 GJB 符合性评价。

**关键词：** 飞行品质；低阶等效系统；强化学习；教师—学生蒸馏；交互式模仿；迁移学习

## 1 引言

本项目的“飞控大模型”指跨多个参数化对象共享的控制策略。研究用滚转角速度内回路验证方法，以 DHC-6 仿真辨识对象检验目标域适配。教师约 4.26 M 参数，源域 tiny 学生为 3,856 参数；文中较好的目标域适配数字属于 75,040 参数 small，不能合并成同一规模模型的成绩。

流程包括品质相关参数分层采样、逐对象教师、统一学生蒸馏和目标域微调。飞行品质标准指导对象构造及部分事后评价；RMSE、峰值误差、操纵总变差率的准入门限由项目另行定义。归档奖励由跟踪误差、作用力能量与力速率动作幅值组成，尚未直接优化全部 GJB 条款，也未证明品质分层优于相同预算的一般参数采样。

本修订版区分三类证据：第 3—5 节主线的归档报告值；第 6.1 节可由随包数据或重建数据核对的结果；第 6.2 节新增的受控对照。归档教师、六轮蒸馏、幅值扫描及 small 迁移的完整记录缺失，不能把同名旧实验摘要当作本版原始证据。版本对应关系见修订说明。

### 1.1 相关工作

飞行品质与学习控制。飞行品质规范及低阶等效系统为对象参数化和响应评价提供依据^{[1,2,13]}。Jansen 与 van Kampen 研究 SAC 飞控的纵向操纵品质评价^{[16]}，是强化学习与航空品质评价的直接相关工作；本次仅核到其摘要、首页与部分引言，不引申未读到的实验细节。Bøhn 等在固定翼姿态控制中研究 SAC 的仿真到实飞迁移，强调延迟与动力学随机化^{[17]}。本项目当前验证范围为滚转参数化对象和 DHC-6 仿真辨识对象。

特权信息与蒸馏。LUPI 与广义蒸馏允许教师、学生拥有不同信息^{[5,18]}；这与单纯缩小网络容量是两个变量。Asymmetric actor–critic 让 critic 使用完整状态、actor 使用部署观测^{[6]}，并不必然需要两阶段教师—学生蒸馏。足式机器人特权学习、RMA 以及航空 Extreme Adaptation 展示了利用历史或潜变量进行动力学适应的路线^{[7–9,15]}，但“信息能够读出”仍不能替代闭环收益的验证。

通用飞控策略。RAPTOR 通过 1,000 个专用 RL 教师训练统一的 2,084 参数循环学生，并在多个真实四旋翼上验证^{[14]}，与本项目多教师到小型通用策略的链路最接近。其相关工作进一步连接 Extreme Adaptation、One Net to Rule Them All、Learning by Cheating、RMA、A-NC 和 DAgger。比较时需要对齐控制层级、动力学覆盖、部署输入和实机证据。竞速飞行^{[11]}、Neural-Fly 抗风适应^{[10]}和 Learning to Fly in Seconds^{[12]}分别提供不同任务和训练范式的参照，不能概括成所有工作都只面向单一平台。

多教师与多轮更新。Policy Distillation 研究将策略知识转移到统一学生^{[19]}；DAgger 在学生访问状态上追加专家标签^{[4]}。Distilling Policy Distillation 强调采样分布和更新目标的区别^{[20]}。反复采集、网络训练 epoch、多代学生成为教师以及多教师合并是不同概念；Born Again Networks 和 Teacher Assistant KD 分别提供多代与分级蒸馏参照^{[21,22]}，不能据此推定飞控品质随轮数单调改善。RAPTOR 的当前策略采样变体也不应直接写成原始 DAgger 的完整历史数据聚合。

本文的潜在贡献是以飞行品质相关参数组织对象族并量化统一策略的失效边界。现有证据尚未建立品质分层采样的对照优势、特权信息差的因果解释或真实固定翼跨机型部署能力。
''')
    replace('> 研究论文 · 版本日期：2026-10-24', '> 核验修订版 · 2026-10-24 · 主线归档结果与本次复核结果分别标注')
    replace('训练环境先以二阶参考模型生成跟踪目标 p_ref；该量是由指令计算得到的期望响应，不是飞机传感器测量值。', '归档训练环境以二阶参考模型和对象真实时延 τp 生成 p_ref；因此该参考不是仅由指令决定。修订代码默认采用不读取对象参数的公共参考，旧实验通过 legacy_plant 模式显式保留。')
    replace('$$ p_ref(s) = [ω_n^{2} / (s^{2} + 2ζ_nω_ns + ω_n^{2})] e^{−τ_ps} p_cmd(s),　ω_n = 2 rad/s,　ζ_n = 0.7 (1) $$', '$$ p_ref(s) = [ω_n² / (s² + 2ζ_nω_ns + ω_n²)] e^{−τ_ref s} p_cmd(s),　ω_n = 2 rad/s,　ζ_n = 0.7 (1) $$\n\n归档模式取 τ_ref=τp，需要真实对象参数；修订公共参考取 τ_ref=0，并从参考模型当前状态计算导数。两种模式不是同一输入条件，归档性能不能自动重命名为公共参考结果。第 6.2.1 节对同一冻结权重作了配对检查。')
    replace('角加速度取 5 deg/s²', '角加速度取 5 rad/s²（约 286.5 deg/s²，与代码常数一致）')
    replace('部署形式的学生只用 176 维本体观测，不含 z_t。p_ref 由二阶参考模型对指令滤波得到，是由指令算出的期望量。', '学生不直接接收 z_t，但归档 176 维输入中的参考仍依赖 τp。因此只能称去掉显式特权向量，不能称全链路无对象参数。公共参考修订消除了这条依赖；传感器估计、执行机构内部量的获得方式仍需在实际部署接口中定义。')
    replace('*图 1　四步方法与各步证据：品质分级采样（5,000 架）→ PPO 教师训练（49 架，46 架通过门限）→ DAgger 蒸馏（3,856 参数，不含特权输入）→ 小样本微调（12 个 DHC-6 状态，中位跟踪误差由 2.91 降至 0.59 deg/s）。*', '*图 1　研究流程及证据边界。源域 tiny 与目标域 small 分别标出；49/46 教师和 small 迁移数值为原稿报告值，本包缺少其完整原始记录。*')
    replace('奖励的三项与品质评定的三个维度一一对应：跟踪误差对应响应精度，作用力能量对应操纵功率，动作幅值对应操纵平滑性。飞行品质参数决定源域对象的采样空间，GJB 条款以门限形式在训练后验收。二者分工明确：奖励负责把策略压到目标响应上，门限负责判定它是否合格。', '奖励三项是响应跟踪、操纵能量和力速率幅值的代理代价；没有建立它们与 GJB 条款逐项等价的关系。品质相关参数用于源域对象构造，训练后用项目定义的 RMSE、Peak、TV 门限准入。LOES 等效延迟另作事后分析，不等同于直接以 GJB 品质指标训练。')
    replace('六轮数据聚合后，分别训练', '原稿记录经过六轮数据聚合后，分别训练')
    replace('学生保留时序特征结构，但只接收本体观测，不使用 12 维教师特权输入。', '学生保留时序特征结构，不直接使用 12 维教师特权输入；归档参考信号的参数依赖见第 2.1 节。六轮主线的逐轮数据与权重未随包完整提供，以下定义说明原稿方法，不构成本次独立复现。')
    replace('拼接维去掉 π 后为 32 维', '去掉显式特权量后的拼接维为 32 维')
    replace('结果均来自仿真或辨识模型，未开展实机飞行、跨随机种子统计或完整飞控系统安全验证。', '主线结果来自仿真或辨识模型，为单策略训练种子的归档结果；第 6 节另列已有与新增两种子检查。未开展实机飞行或完整飞控系统验证。')
    section('### 5.3 第三步：统一学生蒸馏', '### 5.3.1 代表性闭环响应', '''### 5.3 第三步：统一学生蒸馏（归档报告值）

原稿报告六轮 DAgger 后，tiny 的同分布/留出 RMSE 中位倍数为 1.28/1.68，small 为 1.34/1.41。这里统计的是逐对象“学生 RMSE/对应教师 RMSE”的中位数，不能与两组 RMSE 中位数之比混用。

| 学生 | 参数量 | 同分布通过 | 留出通过 | 同分布中位倍数 | 留出中位倍数 |
|---|---:|---:|---:|---:|---:|
| tiny | 3,856 | 37/44 | 3/4 | 1.28× | 1.68× |
| small | 75,040 | 38/44 | 3/4 | 1.34× | 1.41× |

扩大容量未改善同分布误差倍数，但留出倍数下降约 16.1%，通过数仍为 3/4。四个对象的二值通过数不足以排除容量作用。现有实验未独立控制容量、额外信息、教师覆盖及优化程度，因而不能把差距完全归因于特权信息，也不能称压缩无精度损失。逐对象 PPO 教师是经验比较基准，不是已证明的最优上界。

评估集含 48 个对象，三个等级各 16 个；44 个参与蒸馏，4 个为对象级留出。原稿规定每对象 30 条加权指令和 64 条并行确定性轨迹。完整主线逐对象与逐轮记录未随包提供，表中数字待相应原始证据补齐后才能独立复核。

*图 9　原稿归档的学生蒸馏过程图；第 0 轮为行为克隆。其逐轮原始数据未随包提供，不能用 SAE 分支的新实验代替核验。*
''')
    replace('但幅值衰减更明显——学生丢掉的正是教师从对象参数中读到的那部分动态信息。', '但幅值衰减更明显。这是该对象的行为差异，尚不能据此确定误差来自哪一类缺失信息。')
    replace('在固定增益 PID 的对照中，学生策略在分布外对象上的退化幅度显著更小', '在所选固定增益 PID 的对照中，学生策略在分布外对象上的退化幅度较小')
    replace('此后**不再调整**，即无增益调度。', '此后不再调整，即无增益调度。学生使用多对象训练，而该 PID 仅在一个对象整定，因此本对照只支持相对于这套固定 PID 的结果，不能代表相同对象族联合整定或增益调度方法的最优性能。')
    replace('由于对象抽样集合和数量不同，', '由于对象抽样集合和数量不同，不能把通过率差异直接解释为同一总体性能的下降。')
    replace('通过率随幅值增加而下降，与请求力限幅（±22 N）和动作速率限制（88 N/s）在大幅值段同时逼近边界的形态一致：\n控制权限在大幅值段先于响应精度成为约束。', '通过率随幅值增加而下降，大幅值段的请求力限幅（±22 N）和动作速率限制（88 N/s）可能参与约束响应。现有幅值比较未独立改变执行机构边界，尚不能确定饱和与其他误差来源各自的贡献。')
    replace('学生在全部指令与全部对象上通过率更高', '学生在所列幅值组的汇总通过率更高')
    replace('中位 RMSE 随对象变化跨 8.8–18.5 deg/s', '分布外各幅值组的中位 RMSE 为 8.8–18.5 deg/s')
    section('本文对照的是不随对象变化的单一控制律', '### 5.4 第四步：DHC-6 仿真目标上的小样本微调', '本对照说明所选固定 PID 与已训练学生在当前对象族中的差异，不能推出常规控制器必然需要逐对象整定，也未验证学生在实际跨机型部署中免于接口标定或再训练。')
    section('### 5.4 第四步：DHC-6 仿真目标上的小样本微调', '表 4　DHC-6 仿真微调前后跟踪误差（中位数）', '''### 5.4 第四步：DHC-6 仿真目标上的小样本微调（归档报告值）

在归档的 15 deg/s 正阶跃、8 s 时域及 ARX 目标模型下，small 的八个适配状态 RMSE 中位数由 2.913 降至 0.595 deg/s，四个留出状态由 2.662 降至 2.148 deg/s，分别降低 79.6% 与 19.3%。后者描述当前留出状态上的改善，不代表实机或其他指令条件的泛化。

tiny 适配后中位误差为 1.574 deg/s，small 为 0.595 deg/s，前者约为后者的 2.65 倍。但源域初始化性能、网络容量和优化过程未独立控制，不能由此确定“源域容量无关、目标域容量敏感”的分工，更不能直接给出不同规模模型的部署建议。每状态五次更新只是原稿 40 步循环访问八状态的预算说明；尚无增加步数的受控实验来证明其必然改善性能。

本包缺少该 small 模型及 40 步主线的完整原始记录。表 4—5 与图 14—15 保留为归档报告，待原始证据补齐后核验；不使用同包另一模型的 64 步旧协议替代。

''')
    replace('源域结果显示，49 个逐对象教师中多数达到项目门限', '归档源域结果报告，49 个逐对象教师中多数达到项目门限')
    section('DHC-6 微调降低了 8 个适配状态', '### 6.1 延迟表征实验', '''DHC-6 的归档适配数字来自两个不同规模的学生。small 的适配组改善大于留出组，tiny 的适配后误差也高于 small；这提示当前容量和更新配方可能影响目标域适配，但不构成容量或预训练收益的独立因果证据。目标对象来自 DHC-6 仿真记录的 ARX 辨识模型，未验证完整横航向耦合、状态估计误差或实际控制器接机。相同目标数据预算下的随机初始化、冻结策略和常规控制器对照仍需补齐。

飞行品质在本工作中用于源域参数化、覆盖设计和部分事后评价。归档奖励没有逐项加入 GJB 条款，因此当前可支持“在飞行品质相关参数化对象上训练控制器”，不能支持“已用 GJB 品质指标直接优化并证明符合性”。

''')
    probe_rows = []
    names = [('handcrafted_xcorr','互相关'),('dense16','稠密 AE-16'),('raw_history','原始历史'),('pca16','PCA-16'),('l1_3e-03','L1-SAE（较弱稀疏）'),('topk4','Top-k SAE-16'),('l1_3e-02','L1-SAE（较强稀疏）')]
    for key, label in names:
        a, b = probe['probes']['1.2s'][key], probe['probes']['2.0s'][key]
        probe_rows.append(f"| {label} | {a['test_r2']:.3f} | {a['test_mae_ms']:.1f} | {b['test_r2']:.3f} | {b['test_mae_ms']:.1f} |")
    main_tau = tau['batches']['batch']
    tau_rows = []
    for key,label in [('raw_ft','原始历史 raw_ft'),('aux_topk4','SAE-aux'),('topk4','Top-k SAE-16')]:
        d = main_tau[key]
        med = f"{d['tau_e_median']:.3f}" if d['tau_e_median'] is not None else '—'
        bins = ' / '.join(f"{d['by_bin'][b]['tau_e_median']:.3f}" if d['by_bin'][b]['tau_e_median'] is not None else '—' for b in ['short','medium','long'])
        levels = ' | '.join(str(d['levels'][v]) for v in ['level1','level2','level3','exceeds_level3'])
        tau_rows.append(f"| {label} | {d['assessable']}/120 | {med} | {bins} | {levels} |")
    fit_sets = {batch:read(TAU/batch/'fits.json') for batch in ['batch_amp050','batch','batch_amp200','batch_seed2']}
    def good_map(batch,policy):
        return {r['plant_id']:r['tau_e'] for r in fit_sets[batch].values() if r['policy']==policy and r['gate']}
    amp_rows, seed_rows = [], []
    for policy,label in [('raw_ft','原始历史'),('aux_topk4','SAE-aux'),('topk4','Top-k SAE')]:
        sets = [good_map(b,policy) for b in ['batch_amp050','batch','batch_amp200']]
        common = set(sets[0]).intersection(*map(set,sets[1:]))
        counts = ' / '.join(str(len(s)) for s in sets)
        medians = ' / '.join(f'{stats.median(s.values()):.3f}' if s else '—' for s in sets)
        shared = ' / '.join(f'{stats.median(s[k] for k in common):.3f}' if common else '—' for s in sets)
        amp_rows.append(f'| {label} | {counts} | {medians} | {len(common)} | {shared} |')
        s1,s2 = good_map('batch',policy),good_map('batch_seed2',policy)
        shared_ids=set(s1)&set(s2)
        shared_med=' / '.join(f'{stats.median(s[k] for k in shared_ids):.3f}' if shared_ids else '—' for s in [s1,s2])
        full_med=' / '.join(f'{stats.median(s.values()):.3f}' if s else '—' for s in [s1,s2])
        seed_rows.append(f'| {label} | {len(s1)} / {len(s2)} | {full_med} | {len(shared_ids)} | {shared_med} |')
    paired = tau['paired_raw_aux']
    section('### 6.1 延迟表征实验', '### 6.2 后续实验计划', '''### 6.1 延迟表征与等效延迟的核验

#### 6.1.1 数据与输入条件

归档 SAE 分支使用 510 个对象：训练/验证/测试分别为 300/90/120 个，每组在短（τp≤0.05 s）、中（0.05<τp≤0.15 s）、长（τp>0.15 s）时延层均分。每对象运行六档正阶跃（1、2、5、10、21、31 deg/s）、双脉冲、多正弦，共八条指令，产生 489,600 个历史窗口。这里不是主线正负六档的十四指令扫描。

本次用原 tiny 权重及 legacy_plant 参考重建全部对象，检查对象清单相同、4,080 个对象—指令的通过/失败判定没有变化。跨平台数值差异的最大 RMSE 为 0.00063 deg/s，峰值差约 0.00283 deg/s，TV 差约 0.00094 N/s。重建数据保留为独立版本，不覆盖归档数据。测试对象与训练对象分离，但其行为策略来自已有 tiny，不能将整个项目所有历史暴露等同于此处对象划分。

SAE 将 160 维展平历史编码为 16 维；PCA、稠密 AE、稀疏 AE、原始历史和互相关作为对照。互相关使用请求力、响应和指令，不直接读取参考信号，但产生轨迹的策略在归档模式下使用对象相关参考。探针成绩是当前仿真与行为策略中的可解码性，不是闭环改善或参数完全可辨识的证明。

*图 16　原始历史与冻结表示的结构。编码器是否可训练、初始化以及参考构造均是实验条件，不能仅因输出同为 16 维就认为容量完全一致。*

#### 6.1.2 严格时间截止后的延迟探针

原脚本把 1.2 s 的决策步 60 强制抬到首个后续记录步 61，实际使用了 1.22 s 的样本。因此撤回原 0.995/2.9 ms 作为“1.2 s 因果结果”的表述。修订后从 1.0 s 指令起始时刻累积历史窗口，严格要求窗口时间不超过查询时间；1.2 s 查询的最新可用记录为 1.16 s。统计窗的起点也明确为 1.0 s，不能把新旧分数之差全部解释成单独 20 ms 的作用。

重建数据、原冻结编码器和按对象划分的训练/验证/测试用于重新拟合线性探针。结果如下，R² 与 MAE 均在 120 个测试对象、960 个对象—指令 episode 上统计。

| 表征 | 1.2 s R² | 1.2 s MAE (ms) | 2.0 s R² | 2.0 s MAE (ms) |
|---|---:|---:|---:|---:|
''' + '\n'.join(probe_rows) + '''

*图 17　严格按决策时间截止重新计算的延迟探针。柱表示指定查询时刻的结果；窗口不跨越查询时间。原 1.2 s 标注的归档结果仅作错误追溯。*

互相关在这一协议下仍优于所比较的线性读出表示。稠密与稀疏编码存在差异，但尚未隔离编码维数、损失函数和稀疏约束的全部作用。不能从这些结果推出“16 维一定足够”，也不能据此直接选择闭环控制输入。是否改善控制，应由独立闭环对照判断。

#### 6.1.3 归档闭环结果的正确解释

下表保留归档三档时延测试的描述性结果。每档 40 个对象×8 条指令，共 320 个 episode；通过率不是“通过对象数/40”。

| 变体 | 短时延通过率 | 中时延通过率 | 长时延通过率 | 长时延 RMSE 中位 (deg/s) |
|---|---:|---:|---:|---:|
| raw_ft | 93.1% | 95.3% | 90.0% | 0.408 |
| PCA-16 | 60.0% | 60.3% | 51.6% | 1.406 |
| 稠密 AE-16 | 69.1% | 72.5% | 63.7% | 0.731 |
| Top-k SAE-16 | 85.6% | 79.7% | 71.9% | 0.708 |
| SAE-aux | 93.1% | 95.6% | 90.0% | 0.409 |

raw_ft 与 aux 继承已有 tiny，替换分支随机初始化；raw_ft 没有本阶段追加采集，其余分支执行一次采集后训练八个 epoch。标签来自已有 tiny，并非直接查询原始逐对象 PPO 教师。实际采集动作是教师与学生动作的确定性加权混合，β=0.5 表示学生权重；这些实验不应称为八轮原始 DAgger。

旧“仅短/中时延训练→长时延”列不再用作跨时延留出证据：其编码器接触过长时延对象，部分分支继承既有策略，且 dagger_retrain 又将所有训练对象的 BC 样本加入更新。因此该列连“策略更新全程限于短/中时延”的条件也不满足。原 JSON 保留追溯，新受限训练见第 6.2.2 节。

*图 18　归档闭环通过率。初始化和追加采集条件不同，结果只描述这些具体配方；原跨时延列撤出主图。*

#### 6.1.4 τp、τe 与标准适用范围

τp 是本研究对象输入前的运输延迟参数；τe 是对指定闭环频响拟合得到的等效延迟。后者依赖控制器、执行机构、参考模型及拟合协议，不能把 τp 的标签直接替换成 τe。

本研究采用所引 GJB 2874-1997 附录中的四阶滚转 LOES 形式^{[13]}：分母包含螺旋、滚转和荷兰滚模态，分子为三阶，再乘 exp(−τe s)。这说明本文采用的拟合结构，不表示所有对象都必然能由它充分描述。

A21 所列 0.10/0.20/0.25 s 在本文仅作为等效延迟的研究性阈值参照。当前输入为滚转角速度指令，评价对象、驾驶员回路和试验覆盖不等于标准符合性流程；RMSE/Peak/TV 与拟合残差门限均由项目设定。未通过拟合门的样本必须单列，不能赋 τe=0 或解释为延迟更好。

#### 6.1.5 修复时间对齐后的 LOES 评价

归档主批次为 120 对象×3 策略，短/中/长各 40，180 s 多正弦激励。频点由 0.1–10 rad/s 范围内的整数 DFT 栅格生成。原 run_case 保存 u(t_k) 与 p(t_k+0.02) 却按同一时间序号估计频响；因此输出相位含一个控制周期的超前。

本次对全部四批、1,440 个已存频响作 H_corrected(ω)=H_archived(ω)·exp(−jω·0.02)，再按原 16 起点、相同参数边界和随机种子重新拟合。拟合器增加了优化器成功退出检查。这里修复的是现有逐频估计的时间坐标，没有重新生成这 1,440 条轨迹，也没有将新实现的联合谐波回归结果混入本表。参考仍为归档 legacy_plant。

幅值指标实际是 R²_logmag=1−Σ(log|H_fit|−log|H|)²/Σ(log|H|−mean(log|H|))²，不是时域 VAF；项目门限为 R²_logmag≥0.95 且包裹相位 RMSE≤10°。只在过门样本中统计 τe 和阈值档位。

| 策略 | 可评 / 120 | τe 中位 (s) | 短 / 中 / 长中位 (s) | ≤0.10 | (0.10,0.20] | (0.20,0.25] | >0.25 |
|---|---:|---:|---|---:|---:|---:|---:|
''' + '\n'.join(tau_rows) + f'''

*图 19　对齐修复并重新拟合后的 τe。散点仅表示过门样本；右图完整保留未过门对象。档位是 A21 数值阈值参照，不是标准等级认证。*

raw 的可评数仍为 73，aux 从归档 102 变为 101；因此不能简单把所有摘要数值统一加 0.02 s。Top-k 仍为 0/120 可评，表示当前模型和门限不能给出合格估计，不能据此证明每条轨迹都失稳。

不同策略的可评集合不同。raw 与 aux 共同可评 {paired['n']} 个对象上的 τe 中位数分别为 {paired['raw_median']:.5f}/{paired['aux_median']:.5f} s，配对差 aux−raw 的中位数为 {paired['median_paired_delta_aux_minus_raw']:.5f} s。两类中位数不是同一统计量；这组描述性结果不足以宣称哪种策略的飞行品质更好。长时延可评子集的中位 τe 约为 0.32–0.33 s，不能外推到所有长时延对象。

#### 6.1.6 幅值、种子与门限的范围

已完成的设计是种子 1 下三档幅值，以及种子 2 下基准幅值，共四种配置；不是完整的两种子×三幅值六格交叉设计。下表均由时间对齐后的重新拟合结果汇总。

| 策略 | 可评数（0.5 / 1.0 / 2.0 deg/s） | 各自可评集 τe 中位 (s) | 三档共同 n | 共同集三档中位 (s) |
|---|---|---|---:|---|
''' + '\n'.join(amp_rows) + '''

*图 20　时间对齐修复后的幅值检查。共同可评对象固定后比较 τe，并单独展示可评数量；未完成的种子—幅值配置不绘制。*

| 策略 | 可评数（种子 1 / 2） | 各自可评集 τe 中位 (s) | 两种子共同 n | 共同集两种子中位 (s) |
|---|---|---|---:|---|
''' + '\n'.join(seed_rows) + '''

*图 21　基准幅值下两个策略种子的结果。仅在两种子共同可评对象上比较 τe，Top-k 的不可评结果单列。*

这些检查说明所测试配置中的表现，不提供跨训练种子总体、跨机型或标准审定的置信结论。幅值增大时可评比例变化可能与响应形态、非线性及拟合误差共同有关；没有独立噪声实验，不能把原因确定为信噪比提高。

*图 22　保留的归档长时响应诊断例（id_test-3458）。该例可见 Top-k 低频振荡，但一个示例不等于全部 120 个对象的稳定性证明。时间坐标对齐不会改变该功率谱的幅值。*

''')
    reference_rows = []
    for group,label in [('all','全部'),('short','短时延'),('medium','中时延'),('long','长时延')]:
        r=ref[group];a,b=r['legacy_plant'],r['fixed']
        interval=r['bootstrap_95_interval']
        reference_rows.append(f"| {label} | {r['plants']} / {r['episodes']} | {a['pass_rate']*100:.2f}% | {b['pass_rate']*100:.2f}% | {a['rmse_median']:.3f} / {b['rmse_median']:.3f} | {100*r['paired_pass_rate_delta_fixed_minus_legacy']:+.2f} [{100*interval[0]:.2f}, {100*interval[1]:.2f}] |")
    fair_rows=[]
    for key,label in [('raw','原始历史'),('pca16','PCA-16'),('dense16','稠密 AE-16'),('topk4','Top-k SAE-16'),('aux_topk4','SAE-aux')]:
        d=fair['variants'][key]
        fair_rows.append(f"| {label} | {d['s1']['pass_rate']*100:.2f}% / {d['s2']['pass_rate']*100:.2f}% | {d['s1']['rmse_median']:.3f} / {d['s2']['rmse_median']:.3f} | {d['parameters_trainable']} |")
    new_section='''### 6.2 修订后新增对照

#### 6.2.1 公共参考：同一冻结权重的配对检查

固定原 tiny 权重，在原 SAE 的 120 个测试对象、每对象八条指令上，分别提供 legacy_plant 与 fixed 参考。两组均使用同一个不延迟的二阶公共目标计算指标，并将 p(t_k+1) 与该时刻参考对齐。因此这是新定义、相同评价目标下的配对敏感性实验，不能与归档各自参考下的 90% 通过率直接比较。

| 分组 | 对象 / episode | 旧参考通过率 | 公共参考通过率 | RMSE 中位：旧/公共 (deg/s) | 通过率配对差及对象 bootstrap 95% 区间（百分点） |
|---|---|---:|---:|---|---|
'''+'\n'.join(reference_rows)+'''

区间以对象为重采样单位，保留同对象八条指令的相关性，4,000 次 bootstrap，种子 20261024；不覆盖新的策略训练随机性。公共参考在该冻结策略、对象集和统一目标下提高了通过率。由于参考时延与导数计算方式共同变化，这不是某一个因素的独立效果，更不能据此宣称解决了所有未知动力学适应问题。它反驳的是“原有成绩必然全靠真实时延输入”这一未经验证的解释。

*图 23　公共参考与归档参考的配对检查。固定权重、相同对象与公共目标；差值区间按对象重采样。*

#### 6.2.2 训练范围受限、初始化与预算统一的学生对照

新增实验预先记录于 revision/fair_comparison_protocol.json。重新采集公共参考下的 510 对象数据；学生和编码器只在 200 个短/中时延 train_core 对象上更新，以 60 个短/中时延 validation 对象选取训练 checkpoint，在 40 个长时延 id_test 对象、320 个 episode 上评价。标准化、PCA、稠密 AE 和 Top-k AE 的拟合范围也只包含源时延层。

五种学生全部随机初始化，BC 20 个 epoch，随后两轮实际重新采集并聚合的交互式模仿，每轮八个 epoch、96 个合格源对象、相同批大小和学习率。两种策略种子为 20261024/20261025，冻结编码器共用同一套源域训练结果。监督者仍是已有 tiny，其完整预训练暴露不明，因此此处只能称学生及编码器训练范围受限，不能宣称整条知识来源从未见长时延。

| 学生 | 长时延通过率（种子 1 / 2） | 长时延 RMSE 中位（种子 1 / 2，deg/s） | 可训练参数数 |
|---|---|---|---:|
'''+'\n'.join(fair_rows)+'''

以上数字来自修订后实际重训；各模型仍存在架构和可训练参数差异，两个策略种子也不足以估计完整训练随机性。应保留每种子结果，不能用单次最好结果替代整体比较。此处没有新增品质分层采样对照、容量×信息的因子实验或真实飞机验证。

*图 24　修订协议下长时延测试的逐种子结果。学生/编码器训练范围受限，监督者历史暴露未认证；不与旧混合初始化结果合并统计。*

'''
    replace('### 6.2 后续实验计划：执行机构敏感性',new_section+'### 6.3 后续实验计划：执行机构敏感性')
    section('## 7结论','## 参考文献','''## 7 结论

现有材料展示了飞行品质相关参数化对象、逐对象教师、统一学生与仿真目标域适配的研究流程。归档主线报告的学生压缩存在精度损失，扩大模型对留出误差有所改善；没有证据把误差差距完全归因于特权信息。small 的 DHC-6 ARX 适配改善限定于当前辨识对象与测试指令，不能归为 tiny 的成绩或真实飞机验证。

本次核验修复了参考输入的真实参数依赖、跨时延训练样本回流、采集轮次与训练 epoch 混淆、探针越过查询时刻，以及频响输入输出错开一个控制周期的问题。重算后，1.2 s 互相关探针为 R²=0.984、MAE=5.6 ms；raw/aux 的 τe 可评子集中位数为 0.093/0.125 s，必须结合可评比例与共同对象比较。Top-k 未过拟合门不是零延迟或普遍失稳的证明。

公共参考在本次固定权重、统一目标的配对测试中没有造成性能崩溃，并提高了该指标下的通过率。新增训练对照给出了两个策略种子的具体结果，限制了对原有 SAE 排序的解释；它不建立稀疏表示、一般压缩或通用飞控的普遍优劣。当前尚缺品质采样与一般采样的受控比较、容量与信息条件的独立实验、主线原始证据闭合，以及更高保真和实机验证。

''')
    replace('Robotics: Science and Systems, 2017.', 'Robotics: Science and Systems, 2018. DOI: 10.15607/RSS.2018.XIV.008.')
    replace('Science Robotics, 2023, 8(78).', 'Science Robotics, 2022, 7(66): eabm6597. DOI: 10.1126/scirobotics.abm6597.')
    text += '''

13. GJB 2874-1997[S]. 本研究依据交付包中的 A5.4.1.1.1、A5.4.1.1.5/A21 与 A4.9 扫描页作方法和阈值参照；不作符合性判定。

14. J. Eschmann, D. Albani, G. Loianno. RAPTOR: A Foundation Policy for Quadrotor Control[J]. Science Robotics, 2026, 11(114): eaec1481. [原文](https://arxiv.org/abs/2509.11481).

15. D. Zhang, A. Loquercio, J. Tang, et al. A Learning-Based Quadcopter Controller With Extreme Adaptation[J]. IEEE Transactions on Robotics, 2025, 41: 3948–3964. [原文](https://arxiv.org/abs/2409.12949).

16. Jansen, van Kampen. Longitudinal Handling Qualities Evaluation for Soft Actor-Critic Deep Reinforcement Learning Flight Control[C]. AIAA SCITECH, 2025. [DOI](https://doi.org/10.2514/6.2025-2794). 本次阅读范围：摘要、首页及部分引言。

17. E. Bøhn, et al. Data-Efficient Deep Reinforcement Learning for Attitude Control of Fixed-Wing UAVs: Field Experiments[J]. IEEE Transactions on Neural Networks and Learning Systems, 2024. [原文](https://arxiv.org/abs/2111.04153).

18. D. Lopez-Paz, L. Bottou, B. Schölkopf, V. Vapnik. Unifying Distillation and Privileged Information[C]. ICLR, 2016. [原文](https://arxiv.org/abs/1511.03643).

19. A. A. Rusu, et al. Policy Distillation[C]. ICLR, 2016. [原文](https://arxiv.org/abs/1511.06295).

20. W. M. Czarnecki, et al. Distilling Policy Distillation[C]. AISTATS, 2019. [原文](https://proceedings.mlr.press/v89/czarnecki19a.html).

21. T. Furlanello, et al. Born Again Neural Networks[C]. ICML, 2018. [原文](https://proceedings.mlr.press/v80/furlanello18a.html).

22. S. I. Mirzadeh, et al. Improved Knowledge Distillation via Teacher Assistant[C]. AAAI, 2020. [原文](https://ojs.aaai.org/index.php/AAAI/article/view/5963).
'''
    text=text.replace('令误差 e_t = p_ref,t − p_t，角速度归一化尺度为 30 deg/s，则：', '观测误差为 p_ref,t−p_t。归档代码在一个控制周期积分后，以当前区间参考与下一时刻输出计算奖励，记 e_{t+1|t}=p_ref,t−p_{t+1}；归一化尺度为 30 deg/s：')
    text=text.replace('r_t = −50 { [e_t / p_scale]^{2} Δt + 0.02 [F_applied,t / 22 N]', 'r_t = −50 { [e_{t+1|t} / p_scale]^{2} Δt + 0.02 [F_applied,t+1 / 22 N]')
    text=text.replace('| 输入 | 本体感受 176 + 特权信息 12 |', '| 输入 | 常规输入 176（归档参考含 τp）+ 显式特权信息 12 |')
    text=text.replace('以上数字来自修订后实际重训；', '原始历史为 63.44%/66.56%，Top-k 为 57.50%/57.81%，aux 为 67.50%/64.38%。aux 在两个种子上的相对排序相反，没有显示稳定增益。这些新数值不能与旧 90% 直接相减来归因于单个漏洞，因为参考构造、初始化和训练范围均已改变。以上数字来自修订后实际重训；')
    text=re.sub(r'^(## \d)(?=[^\d\s])', r'\1 ', text, flags=re.M)
    text=text.replace('### 5.2 第二步：逐对象教师训练', '### 5.2 第二步：逐对象教师训练（归档报告值）')
    # Embed figures directly in Markdown so HTML and Markdown share captions.
    figures=read(ROOT/'paper_source/figure_map.json')
    figures.update({'1':'paper/revised_pipeline.svg','17':'paper/revised_probe.svg','18':'paper/revised_archived_policies.svg','19':'paper/revised_tau_e.svg','20':'paper/revised_tau_amplitude.svg','21':'paper/revised_tau_seed.svg','23':'paper/revised_reference.svg','24':'paper/revised_fair.svg'})
    def add_image(match):
        number=match.group(1)
        caption=match.group(0)
        return f'![图 {number}，数据与限制见下方图注]({figures[number]})\n\n'+caption
    text=re.sub(r'^\*图 (\d+)\s+.*\*$', add_image, text, flags=re.M)
    (ROOT/'webpage/dhc6_report.md').write_text(text,encoding='utf-8')
    (ROOT/'paper_source/figure_map.json').write_text(json.dumps(figures,ensure_ascii=False,indent=2))
    print('Wrote checked manuscript with regenerated evidence tables')


if __name__ == '__main__':
    main()
