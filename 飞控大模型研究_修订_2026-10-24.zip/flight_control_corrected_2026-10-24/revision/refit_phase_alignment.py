"""Repair archived FRF time coordinates, then refit with the original budget.

Original u[k] was sampled at t_k and y[k] at t_k+0.02. Rotating each output
phasor by exp(-j*w*0.02) expresses it in its physical time coordinate. This
does not regenerate trajectories or change the archived per-tone estimator.
"""
import argparse
import hashlib
import json
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments/gjb_tau_e_20261023"))
import tau_e as T

SOURCE = ROOT / "experiments/gjb_tau_e_20261023/results"
DEST = ROOT / "experiments/gjb_tau_e_20261023/results_phase_aligned"
BATCHES = ("batch", "batch_amp050", "batch_amp200", "batch_seed2")


def work(path_str):
    path = Path(path_str)
    d = json.loads(path.read_text())
    f = np.asarray(d["freqs_hz"])
    H_old = np.asarray(d["H_real"]) + 1j * np.asarray(d["H_imag"])
    H = H_old * np.exp(-2j * np.pi * f * T.DT)
    fit = T.fit_loes(f, H, n_starts=16, seed=0, w_phase=2.0)
    passed = T.gate(fit)
    return path.parent.name, path.stem, {
        "plant_id": d["plant_id"], "policy": d["policy"], "tau_p": d["tau_p"],
        "delay_bin": T.common.delay_bin(d["tau_p"]),
        "fit": fit, "gate": passed, "gate10": passed,
        "tau_e": fit["params"]["tau_e"] if passed else None,
        "a21": T.a21_level(fit["params"]["tau_e"]) if passed else "not_assessable",
        "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "freqs_hz": f.tolist(), "H_real": H.real.tolist(), "H_imag": H.imag.tolist(),
    }


def summary(fits):
    out = T.summarize(fits)
    for policy, stats in out.items():
        rows = [r for r in fits.values() if r["policy"] == policy and r["gate"]]
        stats["by_bin"] = {}
        for bin_name in ("short", "medium", "long"):
            values = [r["tau_e"] for r in rows if r["delay_bin"] == bin_name]
            stats["by_bin"][bin_name] = {"n": len(values),
                "tau_e_median": float(np.median(values)) if values else None}
    return out


def main():
    global DEST
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, default=DEST)
    args = ap.parse_args()
    DEST = args.out.resolve()
    if DEST.exists():
        raise FileExistsError(DEST)
    DEST.mkdir(parents=True)
    paths = [p for b in BATCHES for p in sorted((SOURCE / b).glob("*__*.json"))]
    protocol = {"scope": "FRF phase correction and LOES refit of existing trajectories",
        "n_cases": len(paths), "input_timestamp": "t_k", "original_output_timestamp": "t_k+0.02s",
        "phase_correction": "H_new(w)=H_old(w)*exp(-j*w*0.02)",
        "reference_mode": "legacy_plant", "n_starts": 16, "seed": 0,
        "gate": {"r2_log_magnitude_min": 0.95, "phase_rmse_max_deg": 10},
        "trajectory_regeneration": False, "frf_estimator": "archived separate harmonic regressions",
        "study_design": {"seed1_amplitude_scales": [0.5, 1, 2], "seed2_amplitude_scales": [1]},
        "code_sha256": hashlib.sha256(Path(T.__file__).read_bytes()).hexdigest()}
    (DEST / "protocol.json").write_text(json.dumps(protocol, indent=2))
    fits = {b: {} for b in BATCHES}
    with ProcessPoolExecutor(max_workers=16) as pool:
        for i, (batch, key, value) in enumerate(pool.map(work, map(str, paths)), 1):
            fits[batch][key] = value
            if i % 120 == 0:
                print(f"refit {i}/{len(paths)}", flush=True)
    summaries = {}
    for batch, rows in fits.items():
        out = DEST / batch
        out.mkdir()
        (out / "fits.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1))
        summaries[batch] = summary(rows)
        (out / "summary.json").write_text(json.dumps(summaries[batch], ensure_ascii=False, indent=2))
    base = fits["batch"]
    paired = [(r, base["aux_topk4__" + r["plant_id"]]) for r in base.values()
              if r["policy"] == "raw_ft" and r["gate"]
              and base["aux_topk4__" + r["plant_id"]]["gate"]]
    common = {"n": len(paired),
        "raw_median": float(np.median([a["tau_e"] for a, b in paired])),
        "aux_median": float(np.median([b["tau_e"] for a, b in paired])),
        "median_paired_delta_aux_minus_raw": float(np.median([b["tau_e"] - a["tau_e"] for a, b in paired]))}
    (DEST / "summary_all.json").write_text(json.dumps({"batches": summaries, "paired_raw_aux": common}, indent=2))
    print(json.dumps({"main": summaries["batch"], "paired_raw_aux": common}, indent=2), flush=True)


if __name__ == "__main__":
    main()
