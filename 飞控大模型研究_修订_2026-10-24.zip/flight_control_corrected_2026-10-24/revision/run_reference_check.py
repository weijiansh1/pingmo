"""Paired frozen-checkpoint sensitivity study, with a common evaluation target."""
import hashlib
import json
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import sys

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments/sae_delay_20261023"))
import common as C
from src.envs import batched_p_channel as B

OUT = ROOT / "revision/reference_check"
MODEL = None


def init():
    global MODEL
    torch.set_num_threads(1)
    MODEL = C.load_tiny()


def work(row):
    params = C.plant_parameters(row)
    fixed = B.BatchedRollRateEnv(params, 8, commands=C.COMMANDS, reference_mode="fixed")
    target = fixed.plant.reference
    results = {}
    for mode in ("legacy_plant", "fixed"):
        env = fixed if mode == "fixed" else B.BatchedRollRateEnv(
            params, 8, commands=C.COMMANDS, reference_mode=mode)
        env.command_index[:] = torch.arange(8)
        obs = env.observation()
        se, peak, tv = torch.zeros(8), torch.zeros(8), torch.zeros(8)
        previous = torch.zeros(8)
        n = 0
        with torch.no_grad():
            for step in range(B.EPISODE_STEPS - 1):
                action = MODEL(obs)
                obs, _, p_next = env.step(action)
                if step + 1 >= 50:
                    err = (target[:, step + 1] - p_next) * C.DEG
                    se += err.square()
                    peak = torch.maximum(peak, err.abs())
                    tv += (env.requested - previous).abs()
                    n += 1
                previous = env.requested.clone()
        rmse = (se / n).sqrt().numpy()
        peak = peak.numpy()
        tv = (tv / (n * B.DT_POLICY)).numpy()
        results[mode] = {"rmse": rmse.tolist(), "peak": peak.tolist(), "tv": tv.tolist(),
                        "passed": ((rmse <= 1.5) & (peak <= 5) & (tv <= 12)).tolist()}
    return {"plant_id": row["plant_id"], "tau_p": params.tau_p,
            "delay_bin": C.delay_bin(params.tau_p), "results": results}


def main():
    if OUT.exists():
        raise FileExistsError(OUT)
    OUT.mkdir()
    metas = json.loads((ROOT / "experiments/sae_delay_20261023/results_large/plants.json").read_text())
    ids = {m["plant_id"] for m in metas if m["split"] == "id_test"}
    rows = sorted([r for r in C.load_library() if r["plant_id"] in ids], key=lambda r: r["plant_id"])
    protocol = {"n_plants": len(rows), "n_commands_per_plant": 8, "plant_ids": [r["plant_id"] for r in rows],
        "policy": "frozen archived tiny", "checkpoint_sha256": hashlib.sha256(C.TINY_CKPT.read_bytes()).hexdigest(),
        "variants": ["legacy_plant", "fixed"], "common_metric_target": "fixed undelayed second-order reference",
        "metric_alignment": "p_ref(t_{k+1}) compared with p(t_{k+1})", "metric_start_s": 1.0,
        "training": False, "gate": {"rmse_deg_s": 1.5, "peak_deg_s": 5, "tv_n_s": 12},
        "scope": "Sensitivity to reference construction, not proof of a better retrained policy",
        "bootstrap_unit": "plant (all 8 commands kept together)", "bootstrap_seed": 20261024,
        "reference_change": "remove true tau_p; use causal reference-state derivative"}
    (OUT / "protocol.json").write_text(json.dumps(protocol, indent=2))
    results = []
    with ProcessPoolExecutor(max_workers=16, initializer=init) as pool:
        for i, result in enumerate(pool.map(work, rows), 1):
            results.append(result)
            if i % 20 == 0:
                print(f"reference check {i}/{len(rows)}", flush=True)
    (OUT / "rows.json").write_text(json.dumps(results, indent=1))
    summaries = {}
    for group in ("all", "short", "medium", "long"):
        selected = [r for r in results if group == "all" or r["delay_bin"] == group]
        entry = {"plants": len(selected), "episodes": len(selected) * 8}
        for mode in ("legacy_plant", "fixed"):
            passes = np.array([r["results"][mode]["passed"] for r in selected])
            rmses = np.array([r["results"][mode]["rmse"] for r in selected])
            entry[mode] = {"pass_rate": float(passes.mean()), "rmse_median": float(np.median(rmses))}
        delta = np.array([np.mean(r["results"]["fixed"]["passed"]) -
                          np.mean(r["results"]["legacy_plant"]["passed"]) for r in selected])
        rng = np.random.default_rng(20261024)
        boot = delta[rng.integers(len(delta), size=(4000, len(delta)))].mean(axis=1)
        entry["paired_pass_rate_delta_fixed_minus_legacy"] = float(delta.mean())
        entry["bootstrap_95_interval"] = np.quantile(boot, [0.025, 0.975]).tolist()
        summaries[group] = entry
    (OUT / "summary.json").write_text(json.dumps(summaries, indent=2))
    print(json.dumps(summaries, indent=2), flush=True)


if __name__ == "__main__":
    main()
