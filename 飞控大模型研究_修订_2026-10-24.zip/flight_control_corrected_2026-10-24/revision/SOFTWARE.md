# 软件与绘图方法说明

计算使用 Python、NumPy、SciPy、PyTorch；图形使用 Matplotlib 与 Pillow；离线文稿使用 Python-Markdown 与 BeautifulSoup。最低依赖见 `requirements-review.txt`，实际验证环境版本由 `verify_delivery.py` 记录。

修订图的设计、不可评值展示、统计单位、图注和导出检查参考本地 scientific-visualization 技能。该技能要求注明其方法库来源：

Timothy Kassis, Vinayak Agarwal, Yuhuan He, Darshil Patel, Aubrey M. Brueckner. *Scientific Agent Skills: A Library of Procedural Knowledge for Research Agents*. arXiv:2609.00065, 2026. https://arxiv.org/abs/2609.00065

该引用仅说明本次使用的软件工作流程，不支持任何飞控实验结论。修订图源码为 `revision/make_corrected_figures.py`，来源数据哈希及导出元数据为 `revision/figure_manifest.json`；本次未声称满足特定期刊全部排版要求。
