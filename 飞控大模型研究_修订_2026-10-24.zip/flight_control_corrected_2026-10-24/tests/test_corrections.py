"""Regression checks for deployment information, split boundaries and timing."""
from dataclasses import replace
import importlib.util
import json
import math
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments/sae_delay_20261023"))
sys.path.insert(0, str(ROOT / "experiments/gjb_tau_e_20261023"))
import common as C
import train_policy as TP
import probe_episode as P
import tau_e as T
from src.envs import batched_p_channel as B

torch.set_num_threads(1)


class Corrections(unittest.TestCase):
    def test_fixed_reference_does_not_read_plant_delay(self):
        params = C.plant_parameters(C.load_library()[0])
        a = B.build_plant_batch(replace(params, tau_p=0.01), C.COMMANDS[:1])
        b = B.build_plant_batch(replace(params, tau_p=0.2), C.COMMANDS[:1])
        torch.testing.assert_close(a.reference, b.reference, rtol=0, atol=0)
        torch.testing.assert_close(a.reference_dot, b.reference_dot, rtol=0, atol=0)
        old = B.build_plant_batch(replace(params, tau_p=0.2), C.COMMANDS[:1], "legacy_plant")
        self.assertFalse(torch.equal(a.reference, old.reference))
        self.assertNotEqual(a.delay_len, b.delay_len)

    def test_reference_derivative_is_causal(self):
        command = np.zeros(2000)
        changed = command.copy()
        changed[1001:] = 1
        a, da = B._second_order_reference(command, 0, causal_derivative=True)
        b, db = B._second_order_reference(changed, 0, causal_derivative=True)
        np.testing.assert_array_equal(a[:1001], b[:1001])
        np.testing.assert_array_equal(da[:1001], db[:1001])

    def test_probe_never_uses_future_record(self):
        steps = np.arange(40, 100, 3)
        mask = P.causal_window_mask(steps, 1.2)
        self.assertGreater(mask.sum(), 0)
        self.assertLessEqual(steps[mask].max() * .02, 1.2)
        self.assertNotIn(61, steps[mask])

    def data(self):
        # Action labels identify source windows (1,3), forbidden long windows (99),
        # and validation windows (5), independent of how features are implemented.
        return {"idx": {"train": np.array([0,1,2]), "val": np.array([3,4])},
            "window_tau": np.array([.02,.19,.10,.04,.18]),
            "action": np.array([1.,99.,3.,5.,99.]),
            "obs": np.zeros((5,176), dtype=np.float32)}

    def test_source_filter_survives_dagger_retraining(self):
        data = self.data()
        dagger = {"history": np.zeros((1,32,5), dtype=np.float32),
                  "current": np.zeros((1,9), dtype=np.float32),
                  "older": np.zeros((1,7), dtype=np.float32), "action": np.array([7.])}
        captured = {}
        def train(model, batches, tr, va, **kwargs):
            captured["train"] = batches["action"][tr].tolist()
            captured["val"] = batches["action"][va].tolist()
            return {"val_mse": 0.0}
        with patch.object(TP, "_train_loop", train):
            TP.dagger_retrain(data, C.TinyStudent(), "tiny", None, dagger,
                             epochs=1, source_only=True)
        self.assertEqual(captured["train"], [1.,3.,7.])
        self.assertEqual(captured["val"], [5.])

    def test_source_filter_also_applies_to_bc(self):
        data = self.data()
        captured = {}
        def train(model, batches, tr, va, **kwargs):
            captured["train"] = batches["action"][tr].tolist()
            captured["val"] = batches["action"][va].tolist()
            return {"val_mse": 0.0}
        with patch.object(TP, "_train_loop", train):
            TP.train_variant("raw", data, 1, source_only=True)
        self.assertEqual(captured["train"], [1.,3.])
        self.assertEqual(captured["val"], [5.])

    def test_frequency_response_recovers_known_delay(self):
        t = np.arange(5000) / T.FS
        f = np.array([.023,.117,.471,.936])
        delay = .073
        x = sum(np.sin(2*np.pi*fi*t) for fi in f)
        y = sum(1.7*np.sin(2*np.pi*fi*(t-delay)) for fi in f)
        H, residual = T.estimate_frf(x, y, f)
        np.testing.assert_allclose(H, 1.7*np.exp(-2j*np.pi*f*delay), atol=1e-11)
        self.assertLess(residual, 1e-11)

    def test_timestamp_phase_correction_sign(self):
        t = np.arange(5000) / T.FS
        f = np.array([.05,.19,.61])
        delay = .08
        x = sum(np.sin(2*np.pi*fi*t) for fi in f)
        next_output = sum(np.sin(2*np.pi*fi*(t+T.DT-delay)) for fi in f)
        H, _ = T.estimate_frf(x, next_output, f)
        repaired = H*np.exp(-2j*np.pi*f*T.DT)
        np.testing.assert_allclose(repaired, np.exp(-2j*np.pi*f*delay), atol=1e-11)

    def test_unassessable_values_never_enter_tau_summary(self):
        def row(ok, tau):
            return {"policy":"raw_ft", "gate":ok, "tau_e":tau, "a21":"level1",
                    "fit":{"ok":True,"vaf_mag":.99,"phase_rmse_deg":1}}
        summary = T.summarize({"ok":row(True,.05), "bad":row(False,.49)})["raw_ft"]
        self.assertEqual(summary["tau_e_median"], .05)
        self.assertEqual(summary["assessable"], 1)

    def test_fitting_does_not_try_to_read_its_own_summaries(self):
        with tempfile.TemporaryDirectory() as folder:
            d = Path(folder)/"check"
            d.mkdir()
            (d/"summary.json").write_text("{}")
            (d/"fits.json").write_text("{}")
            with patch.object(T, "RESULT_DIR", Path(folder)):
                self.assertEqual(T.fit_saved("check"), {})

    def test_nondefault_excitation_duration_is_honored(self):
        profile, freqs = T.multisine_profile(duration_s=60)
        self.assertEqual(profile.duration_s, 60)
        np.testing.assert_allclose(freqs*60, np.round(freqs*60))

    def test_portable_frontend_checkpoint_round_trip(self):
        front = TP.make_frontend("topk4")
        model = TP.AuxPolicy(front).eval()
        x = torch.randn(4,176)
        with tempfile.TemporaryDirectory() as folder:
            config = TP.save_config(Path(folder)/"aux.pt", model, "aux", "topk4")
            config["data_dir"] = "/nonexistent/original/training/location"
            with patch.object(TP, "make_frontend", side_effect=RuntimeError("must use embedded frontend")):
                loaded = TP.build_model(config)
            torch.testing.assert_close(model(x), loaded(x), atol=0, rtol=0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
