"""Disturbance models placeholder."""
