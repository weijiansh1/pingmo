"""Aircraft sample library placeholder."""
