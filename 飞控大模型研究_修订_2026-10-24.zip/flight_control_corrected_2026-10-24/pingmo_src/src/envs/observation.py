"""Observation construction placeholder."""
