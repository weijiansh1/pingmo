"""Domain randomization placeholder."""
