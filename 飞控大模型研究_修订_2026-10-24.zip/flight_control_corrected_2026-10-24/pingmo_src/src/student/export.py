"""Model export placeholder."""
