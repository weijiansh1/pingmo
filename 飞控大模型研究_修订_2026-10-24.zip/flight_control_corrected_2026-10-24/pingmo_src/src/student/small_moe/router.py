"""Small MoE router placeholder."""
