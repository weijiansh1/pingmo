"""Small MoE experts placeholder."""
