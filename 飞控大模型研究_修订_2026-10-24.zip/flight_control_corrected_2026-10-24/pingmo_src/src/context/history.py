"""History context placeholder."""
