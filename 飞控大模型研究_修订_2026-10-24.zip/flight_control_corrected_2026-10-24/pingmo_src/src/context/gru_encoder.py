"""GRU encoder placeholder."""
