"""Dynamics encoder placeholder."""
