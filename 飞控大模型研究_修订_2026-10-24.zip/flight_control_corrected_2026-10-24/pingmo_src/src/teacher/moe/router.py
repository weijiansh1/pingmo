"""MoE router placeholder."""
