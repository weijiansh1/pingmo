"""MoE critic placeholder."""
