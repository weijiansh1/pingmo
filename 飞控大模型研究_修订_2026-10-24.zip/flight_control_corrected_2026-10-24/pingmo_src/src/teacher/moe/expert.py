"""MoE expert placeholder."""
