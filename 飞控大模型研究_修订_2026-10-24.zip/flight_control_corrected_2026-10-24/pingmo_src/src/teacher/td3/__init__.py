"""Deterministic specialist Teacher components."""
