"""Baseline controller interface placeholder."""
