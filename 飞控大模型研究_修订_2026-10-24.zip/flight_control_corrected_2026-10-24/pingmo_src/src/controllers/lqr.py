"""LQR controller placeholder."""
