"""Transfer adapters placeholder."""
