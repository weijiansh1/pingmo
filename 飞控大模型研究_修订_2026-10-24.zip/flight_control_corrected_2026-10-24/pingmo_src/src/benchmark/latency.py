"""Inference latency placeholder."""
