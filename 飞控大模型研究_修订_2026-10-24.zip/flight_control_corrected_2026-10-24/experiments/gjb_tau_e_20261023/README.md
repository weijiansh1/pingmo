# LOES 等效延迟评价：时间对齐修订版

`results/` 是原始结果，`results_phase_aligned/` 是对原始频响作时间坐标修正后重新拟合的结果。新运行的评价器默认写 `results_corrected/`，不得混用三者。

原 `run_case` 将 t_k 的指令与 t_k+0.02 s 的输出按相同时刻估计频响，使输出相位多出一个采样步长的超前。已修正新评价器，在步进前同时记录输入和状态输出；已存频响则用 `H_corrected=H_old*exp(-j*w*0.02)` 恢复物理时间坐标，再进行 16 起点重新拟合。

新评价器还修复：联合谐波回归的多正弦残差定义、可配置激励时长、重复拟合误读汇总文件、未过门 τe 混入中位数，以及优化器未成功退出仍接受结果的问题。`vaf_mag` 保留为兼容字段，真实定义是对数幅值的 `1-SSE/SST`，新结果同时提供 `r2_log_magnitude`。

## 已重算结果

共四种配置、1,440 个频响：种子 1 的每分量 0.5/1/2 deg/s，以及种子 2 的基准 1 deg/s。并未完成两种子×三幅值的完整六格设计。

| 主批策略 | 可评 / 120 | τe 中位 | 短 / 中 / 长中位 |
|---|---:|---:|---|
| raw_ft | 73 | 0.093 s | 0.062 / 0.147 / 0.319 s |
| SAE-aux | 101 | 0.125 s | 0.054 / 0.145 / 0.329 s |
| Top-k | 0 | 不可用 | 不可用 |

raw/aux 共同可评 71 个对象上的中位数为 0.09315/0.09480 s。不能直接比较两种策略各自可评子集的中位数来排序品质。不可评不等于 τe=0，也不是所有轨迹已证明失稳。

这些结果仍使用旧参考和旧逐频回归，只修复时间坐标并重新拟合；新程序的联合回归不会被冒充为这一批的历史估计。门限为项目设定的 R²_logmag≥0.95、相位 RMSE≤10°，A21 数值仅作研究性参照，不构成标准符合性。

## 运行

从包根目录运行，新输出使用独立 tag：

```bash
python experiments/gjb_tau_e_20261023/tau_e.py synthetic
python experiments/gjb_tau_e_20261023/tau_e.py pilot --n-per-bin 4 --workers 12 --reference-mode fixed --tag pilot_new
python experiments/gjb_tau_e_20261023/tau_e.py fit --results-dir experiments/gjb_tau_e_20261023/results_corrected --tag pilot_new
```

新默认输入是公共参考；若要评价归档参考下的旧策略，显式加 `--reference-mode legacy_plant`。`--policy-dir` 可选择新的自包含检查点目录（策略文件名需与 CLI 所选策略一致）。

例如评价本次新训练的三种策略：

```bash
python experiments/gjb_tau_e_20261023/tau_e.py pilot --n-per-bin 1 --workers 3 --policy-dir experiments/sae_delay_20261023/results_corrected/policies_strict_s1 --policies raw topk4 aux_topk4 --reference-mode fixed --tag strict_s1_new
```

重做归档相位修复及重拟合：

```bash
python revision/refit_phase_alignment.py --out runs/tau_phase_recomputed
```

已完成结果默认在 `results_phase_aligned/`，脚本拒绝覆盖，重复计算请指定新输出目录。新增图表与全文来自该目录的 JSON，代码不将未过门样本的拟合 τe 纳入总体中位数。
