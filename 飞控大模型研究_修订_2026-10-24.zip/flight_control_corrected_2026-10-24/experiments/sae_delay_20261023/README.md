# SAE 与时延实验：核验修订说明

归档结果位于 `results_large/`，修订公共参考下的新数据与学生位于 `results_corrected/`，旧参考重建数据和严格因果探针位于 `replay_legacy/`。它们不能混成同一实验。

原分支使用六档正阶跃加双脉冲、多正弦，共 8 条指令。旧文案“±六档加两种指令共 8 条”错误；正负六档应为 14 条。

## 已确认并修复

1. `common.py` 自动定位随包 `pingmo_src` 和 tiny 权重，支持 Linux/Windows。
2. 公共参考默认不读真实 τp，旧参考只能显式选择 `legacy_plant`。
3. `probe_episode.py` 不再把查询时刻向未来抬升；读取 `--data` 对应的特征，记录实际最新样本时间。
4. `train_policy.py` 在 BC 和 DAgger 更新中使用同一短/中时延索引；采集对象先筛选再抽取。
5. `train_sae.py` 与 `features.py` 支持 `--source-only`，标准化、PCA、编码器训练和验证范围一致；策略训练检查元数据，不接受范围不明的旧编码器。
6. `--dagger-rounds` 表示重新采集的次数；`--dagger-epochs` 是每轮更新 epoch。每轮保存新增及累计窗口数。
7. 新对照默认从随机初始化开始，raw 也获得相同追加采集预算。继承已有 tiny 的对照须显式指定 pretrained；source-only 拒绝继承其未知训练暴露。
8. 新策略检查点内嵌冻结前端，可移到不同目录加载；`eval` 模式执行评价，不再重新训练。

## 旧结论的处理

- 原“1.2 s R²=0.995、MAE=2.9 ms”实际使用 1.22 s 样本，已撤回该时间口径。
- 严格 1.2 s 截止重算为 R²=0.984、MAE=5.6 ms；前缀从 1.0 s 起，最新记录是 1.16 s。新旧分数不是仅移动一个样本后的单因素比较。
- 旧“8 轮”实际是一次采集加 8 epoch，标签来自 tiny。
- 旧 source-only 分支的编码器见过长时延，且 DAgger 重新加入全部 BC 训练样本；旧跨时延列不再作为有效训练隔离证据。
- 旧 raw/aux 继承权重，替换分支从头训练；不能用旧排序归因于稀疏性。

## 已完成的新对照

公共参考；学生与编码器用 200 个短/中时延对象训练、60 个源时延验证对象选择 checkpoint，40 个长时延测试对象×8 指令评价。五种学生统一随机初始化、BC 20 epoch、两轮采集各 8 epoch、每轮 96 个源对象，策略种子 20261024/20261025。

| 方法 | 长时延通过率 s1 / s2 |
|---|---|
| raw | 63.44% / 66.56% |
| PCA-16 | 69.69% / 58.75% |
| dense AE-16 | 65.31% / 56.88% |
| Top-k SAE-16 | 57.50% / 57.81% |
| SAE-aux | 67.50% / 64.38% |

aux 的相对优势随种子变化。编码器共用一个训练种子，方法架构及可训练参数数不同；标签教师为原 tiny，完整预训练范围未知。不作普遍优劣或整条链路未见长时延的结论。

## 从零复现

从交付包根目录运行。以下使用新目录 `runs/strict_source`，不会覆盖已有结果：

```bash
python experiments/sae_delay_20261023/collect.py --n-train 100 --n-val 30 --n-test 40 --workers 12 --seed 20261023 --reference-mode fixed --out runs/strict_source
python experiments/sae_delay_20261023/train_sae.py --data runs/strict_source --source-only --suite --names dense16 topk4 --epochs 20 --seed 20261024
python experiments/sae_delay_20261023/features.py --data runs/strict_source --source-only
python experiments/sae_delay_20261023/train_policy.py train --data runs/strict_source --source-only --initialization scratch --variants raw pca16 dense16 topk4 aux_topk4 --epochs 20 --dagger-rounds 2 --dagger-epochs 8 --dagger-plants 96 --workers 12 --seed 20261024 --tag strict_s1
python experiments/sae_delay_20261023/train_policy.py train --data runs/strict_source --source-only --initialization scratch --variants raw pca16 dense16 topk4 aux_topk4 --epochs 20 --dagger-rounds 2 --dagger-epochs 8 --dagger-plants 96 --workers 12 --seed 20261025 --tag strict_s2
```

重建归档输入条件下的探针：

```bash
python experiments/sae_delay_20261023/collect.py --n-train 100 --n-val 30 --n-test 40 --workers 12 --seed 20261023 --reference-mode legacy_plant --out runs/probe_replay
python revision/rebuild_archived_features.py --data runs/probe_replay
python experiments/sae_delay_20261023/probe_episode.py --data runs/probe_replay
```

若单独评价新的自包含检查点，`train_policy.py eval --data runs/strict_source --source-only --variants raw pca16 dense16 topk4 aux_topk4 --tag strict_s1` 只读已存权重。完整数据存在时可重算评估；论文重建只需要保留的 JSON。
