"""Train and evaluate policies that read raw history vs frozen SAE features.

    cd pingmo
    python experiments/sae_delay_20261023/train_policy.py train --variants pca16 topk4 aux_topk4

Archived results used different initializations and collection budgets. New
runs record these choices explicitly and default to scratch initialization with
the same update and DAgger budgets. Frozen frontends are not trainable parameters.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import torch
from torch import nn

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import common  # noqa: E402
import probe as P  # noqa: E402
from train_sae import SAE  # noqa: E402
from src.teacher.ppo.networks import HistoryConv  # noqa: E402
from src.teacher.residual import ResidualMLPTrunk  # noqa: E402

torch.set_num_threads(8)

DATA = HERE / "results_large"
FEAT = DATA / "features"


# --------------------------------------------------------------------- models
class Frontend(nn.Module):
    def __init__(self, kind: str, mu: np.ndarray, sd: np.ndarray,
                 encoder: nn.Module | None = None,
                 components: np.ndarray | None = None) -> None:
        super().__init__()
        self.kind = kind
        self.register_buffer("mu", torch.tensor(mu, dtype=torch.float32))
        self.register_buffer("sd", torch.tensor(sd, dtype=torch.float32))
        self.encoder = encoder
        if components is not None:
            self.register_buffer("components", torch.tensor(components, dtype=torch.float32))
        if encoder is not None:
            for p in encoder.parameters():
                p.requires_grad_(False)

    def forward(self, hist: torch.Tensor) -> torch.Tensor:
        x = (hist.reshape(-1, 160) - self.mu) / self.sd
        if self.kind == "pca":
            return x @ self.components.T
        return self.encoder.encode(x)


class BodyPolicy(nn.Module):
    def __init__(self, feature_dim: int = 16) -> None:
        super().__init__()
        self.body = ResidualMLPTrunk(feature_dim + 9 + 7, 32, 1)
        self.head = nn.Linear(32, 1, bias=False)

    def forward(self, feat: torch.Tensor, feat_neg: torch.Tensor,
                current: torch.Tensor, older: torch.Tensor) -> torch.Tensor:
        logits = self.head(self.body(torch.cat([feat, current, older], dim=-1)))
        logits_neg = self.head(self.body(torch.cat([feat_neg, -current, -older], dim=-1)))
        return torch.tanh(0.5 * (logits - logits_neg).float())


class OnlinePolicy(nn.Module):
    def __init__(self, body: BodyPolicy, frontend: Frontend) -> None:
        super().__init__()
        self.body = body
        self.frontend = frontend

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        cur, hist, old = common.split_observation(obs)
        feat = self.frontend(hist)
        feat_neg = self.frontend(-hist)
        return self.body(feat, feat_neg, cur, old)


class AuxPolicy(nn.Module):
    """Tiny Student with frozen SAE features appended to the conv features."""

    def __init__(self, frontend: Frontend) -> None:
        super().__init__()
        self.encoder = HistoryConv(width=8)
        self.frontend = frontend
        self.body = ResidualMLPTrunk(16 + 16 + 9 + 7, 32, 1)
        self.head = nn.Linear(32, 1, bias=False)

    def _logits(self, obs: torch.Tensor) -> torch.Tensor:
        cur, hist, old = common.split_observation(obs)
        conv = self.encoder(hist)
        with torch.no_grad():
            z = self.frontend(hist)
        return self.head(self.body(torch.cat([conv, z, cur, old], dim=-1)))

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        return torch.tanh(0.5 * (self._logits(obs) - self._logits(-obs)).float())


def init_aux_from_tiny(aux: AuxPolicy) -> None:
    ck = torch.load(common.TINY_CKPT, map_location="cpu", weights_only=False)
    sd = ck["student"]
    aux.encoder.load_state_dict({k.split(".", 1)[1]: v for k, v in sd.items()
                                 if k.startswith("encoder.")})
    old_w = sd["body.projection.weight"]
    new_w = aux.body.projection.weight.data
    new_w[:, :16] = old_w[:, :16]
    new_w[:, 32:41] = old_w[:, 16:25]
    new_w[:, 41:48] = old_w[:, 25:32]
    new_w[:, 16:32] = 0.0
    aux.body.projection.bias.data.copy_(sd["body.projection.bias"])
    for name, param in aux.body.named_parameters():
        if name.startswith("projection."):
            continue
        param.data.copy_(sd[f"body.{name}"])
    for name, buf in aux.body.named_buffers():
        buf.data.copy_(sd[f"body.{name}"])
    aux.head.weight.data.copy_(sd["head.weight"])


class DaggerPolicy(nn.Module):
    """Mixture of learner and tiny labels used only to collect DAgger states."""

    def __init__(self, learner: nn.Module, labels: nn.Module, beta: float) -> None:
        super().__init__()
        self.learner = learner
        self.labels = labels
        self.beta = beta

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        return (1.0 - self.beta) * self.labels(obs) + self.beta * self.learner(obs)


# ----------------------------------------------------------------------- data
def build_arrays(data_dir: Path) -> dict:
    data = P.load_dataset(data_dir)
    arrays = data["arrays"]
    metas = data["metas"]
    split = np.array([m["split"] for m in metas])
    tau = np.array([m["tau_p"] for m in metas], dtype=np.float64)
    plant_index = arrays["plant_index"]
    window_split = split[plant_index]
    window_tau = tau[plant_index]
    obs = np.concatenate([
        arrays["current"],
        arrays["history"].reshape(len(arrays["history"]), -1),
        arrays["older"],
    ], axis=1).astype(np.float32)
    idx = {
        "train": np.where(window_split == "train_core")[0],
        "val": np.where(window_split == "validation")[0],
        "test": np.where(window_split == "id_test")[0],
    }
    return {"arrays": arrays, "metas": metas, "split": split, "tau": tau,
            "plant_index": plant_index, "obs": obs, "idx": idx,
            "window_tau": window_tau, "action": arrays["action"]}


def training_indices(data: dict, source_only: bool = False) -> tuple[np.ndarray, np.ndarray]:
    tr, va = data["idx"]["train"], data["idx"]["val"]
    if source_only:
        tr = tr[data["window_tau"][tr] <= 0.15]
        va = va[data["window_tau"][va] <= 0.15]
    if not len(tr) or not len(va):
        raise ValueError("Training and validation splits must both be nonempty")
    return tr, va


def load_feature(name: str, n: int) -> tuple[np.ndarray, np.ndarray]:
    z = np.load(FEAT / f"{name}.npy").astype(np.float32)
    zn = np.load(FEAT / f"{name}_neg.npy").astype(np.float32)
    if len(z) != n:
        raise ValueError(f"feature {name} has {len(z)} rows, expected {n}")
    return z, zn


def make_frontend(name: str, data_dir: Path | None = None) -> Frontend:
    data_dir = data_dir or DATA
    feat_dir = data_dir / "features"
    meta = json.loads((feat_dir / "meta.json").read_text(encoding="utf-8"))
    entry = meta["models"][name]
    std = np.load(feat_dir / "standardizer.npz")
    mu, sd = std["mu"], std["sd"]
    if entry["kind"] == "pca":
        components = np.load(feat_dir / "pca16_components.npy")
        return Frontend("pca", mu, sd, components=components)
    model_path = data_dir / entry["model"].replace("\\", "/")
    payload = torch.load(model_path, map_location="cpu", weights_only=False)
    stats = payload["stats"]
    sae = SAE(mode=stats["mode"], topk=stats["topk"], latent=stats["latent"],
              hidden=stats["hidden"])
    sae.load_state_dict(payload["state"])
    sae.eval()
    return Frontend(stats["mode"], mu, sd, encoder=sae)


# -------------------------------------------------------------------- training
def _train_loop(model: nn.Module, batches: dict, train_idx: np.ndarray,
                val_idx: np.ndarray, epochs: int, batch: int = 1024,
                lr: float = 1e-3) -> dict:
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-5)
    forward_keys = [k for k in batches if k != "action"]

    def run(indices):
        perm = torch.randperm(len(indices))
        total = 0.0
        for start in range(0, len(indices), batch):
            take = indices[perm[start:start + batch]]
            pred = model(*[batches[k][take] for k in forward_keys]).squeeze(-1)
            target = batches["action"][take]
            loss = (pred - target).pow(2).mean()
            opt.zero_grad()
            loss.backward()
            opt.step()
            total += float(loss.detach()) * len(take)
        return total / len(indices)
    best = float("inf")
    best_epoch = -1
    best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
    curve = []
    for epoch in range(epochs):
        tr = run(train_idx)
        with torch.no_grad():
            pred = model(*[batches[k][val_idx] for k in forward_keys]).squeeze(-1)
            va = float((pred - batches["action"][val_idx]).pow(2).mean())
        curve.append({"epoch": epoch + 1, "train_mse": tr, "val_mse": va})
        if va < best - 1e-9:
            best = va
            best_epoch = epoch + 1
            best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
    model.load_state_dict(best_state)
    model.eval()
    return {"best_epoch": best_epoch, "val_mse": best, "curve": curve}


def train_variant(variant: str, data: dict, epochs: int, source_only: bool = False,
                  init_tiny: bool = False, lr: float = 5e-4,
                  batch: int = 1024) -> tuple[nn.Module, dict, str]:
    train_idx, val_idx = training_indices(data, source_only)
    obs = torch.tensor(data["obs"])
    action = torch.tensor(data["action"], dtype=torch.float32)
    if variant in ("raw", "raw_ft"):
        model = common.TinyStudent()
        if init_tiny:
            ck = torch.load(common.TINY_CKPT, map_location="cpu", weights_only=False)
            model.load_state_dict(ck["student"])
        stats = _train_loop(model, {"obs": obs, "action": action}, train_idx, val_idx,
                            epochs=epochs, batch=batch, lr=lr)
        return model, stats, "tiny"
    if variant.startswith("aux_"):
        feature = variant[4:]
        frontend = make_frontend(feature)
        model = AuxPolicy(frontend)
        if init_tiny:
            init_aux_from_tiny(model)
        stats = _train_loop(model, {"obs": obs, "action": action}, train_idx, val_idx,
                            epochs=epochs, batch=batch, lr=lr)
        return model, stats, "aux"
    # Frozen feature variants: precompute features and train the body only.
    feature = variant
    z, zn = load_feature(feature, len(obs))
    body = BodyPolicy()
    # The loop indexes batches with global indices, so build full-size tensors.
    full = {
        "feat": torch.tensor(z), "feat_neg": torch.tensor(zn),
        "current": torch.tensor(data["arrays"]["current"]),
        "older": torch.tensor(data["arrays"]["older"]),
        "action": action,
    }
    stats = _train_loop(body, full, train_idx, val_idx, epochs=epochs, batch=batch, lr=lr)
    return body, stats, "feature"


# ------------------------------------------------------------------ evaluation
_EVAL_MODEL = None
_EVAL_CONFIG = None


def _init_eval(config: dict) -> None:
    global _EVAL_MODEL, _EVAL_CONFIG
    torch.set_num_threads(1)
    _EVAL_CONFIG = config
    _EVAL_MODEL = build_model(config)


def build_model(config: dict) -> nn.Module:
    kind = config["kind"]
    if kind == "tiny":
        model = common.TinyStudent()
        model.load_state_dict(config["state_dict"])
        return model.eval()
    if kind == "feature":
        body = BodyPolicy()
        body.load_state_dict(config["state_dict"])
        frontend = frontend_from_config(config)
        return OnlinePolicy(body, frontend).eval()
    if kind == "aux":
        frontend = frontend_from_config(config)
        model = AuxPolicy(frontend)
        missing = model.load_state_dict(config["state_dict"], strict=False)
        if any(not k.startswith("frontend.") for k in missing.missing_keys):
            raise ValueError(f"aux checkpoint missing keys: {missing.missing_keys}")
        return model.eval()
    raise ValueError(kind)


def _eval_row(row: dict) -> dict:
    result = common.run_rollout(_EVAL_MODEL, row, record=False,
                                reference_mode=_EVAL_CONFIG.get("reference_mode", "legacy_plant"))
    return {"plant_id": row["plant_id"], "split": row["split"],
            "level": int(row["gjb_level"]),
            "tau_p": float(row["parameters"]["tau_p"]),
            "delay_bin": common.delay_bin(float(row["parameters"]["tau_p"])),
            "metrics": {k: [float(x) for x in v]
                        for k, v in result["metrics"].items()}}


def evaluate(config: dict, rows: list[dict], workers: int) -> list[dict]:
    with ProcessPoolExecutor(max_workers=workers, initializer=_init_eval,
                             initargs=(config,)) as pool:
        return list(pool.map(_eval_row, rows))


def summarize(rows: list[dict]) -> dict:
    out = {}
    for name in ("short", "medium", "long"):
        group = [r for r in rows if r["delay_bin"] == name]
        if not group:
            continue
        rm = np.array([r["metrics"]["rmse"] for r in group])
        pk = np.array([r["metrics"]["peak"] for r in group])
        tv = np.array([r["metrics"]["tv"] for r in group])
        ok = (rm <= 1.5) & (pk <= 5.0) & (tv <= 12.0)
        out[name] = {
            "n_plants": len(group),
            "n_episodes": int(rm.size),
            "rmse_median": float(np.median(rm)),
            "rmse_p90": float(np.percentile(rm, 90)),
            "peak_median": float(np.median(pk)),
            "tv_median": float(np.median(tv)),
            "pass_rate": float(ok.mean()),
        }
    return out


def frontend_from_config(config: dict) -> Frontend:
    spec = config.get("frontend")
    if spec is None:
        data_dir = Path(config.get("data_dir", str(DATA)))
        return make_frontend(config["feature"], data_dir if data_dir.is_dir() else DATA)
    encoder = None
    if spec["kind"] != "pca":
        encoder = SAE(mode=spec["kind"], topk=spec["topk"],
                      latent=spec["latent"], hidden=spec["hidden"])
    front = Frontend(spec["kind"], spec["mu"].numpy(), spec["sd"].numpy(),
                     encoder=encoder, components=spec.get("components"))
    front.load_state_dict(spec["state"])
    return front.eval()


def save_config(path: Path, model: nn.Module, kind: str, feature: str | None,
                 reference_mode: str = "fixed") -> dict:
    state = {k: v.detach().cpu() for k, v in model.state_dict().items()
             if not k.startswith("frontend.")}
    config = {"kind": kind, "feature": feature, "state_dict": state,
              "data_dir": str(DATA), "reference_mode": reference_mode,
              "schema_version": 2}
    if feature is not None:
        front = model.frontend if kind == "aux" else make_frontend(feature)
        spec = {"kind": front.kind, "mu": front.mu.cpu(), "sd": front.sd.cpu(),
                "state": {k: v.detach().cpu() for k, v in front.state_dict().items()}}
        if front.kind == "pca":
            spec["components"] = front.components.cpu().numpy()
        else:
            spec.update(topk=front.encoder.topk, latent=front.encoder.encoder[-1].out_features,
                        hidden=front.encoder.encoder[0].out_features)
        config["frontend"] = spec
    torch.save(config, path)
    return config


def load_config(path: Path) -> dict:
    return torch.load(path, map_location="cpu", weights_only=False)


# ---------------------------------------------------------------------- DAgger
_DAGGER_POLICY = None
_DAGGER_LABEL = None
_DAGGER_REFERENCE_MODE = "fixed"


def _init_dagger(config: dict, beta: float) -> None:
    global _DAGGER_POLICY, _DAGGER_LABEL, _DAGGER_REFERENCE_MODE
    torch.set_num_threads(1)
    learner = build_model(config)
    _DAGGER_LABEL = common.load_tiny()
    _DAGGER_POLICY = DaggerPolicy(learner, _DAGGER_LABEL, beta)
    _DAGGER_REFERENCE_MODE = config.get("reference_mode", "legacy_plant")


def _dagger_row(row: dict) -> dict:
    return common.run_rollout(_DAGGER_POLICY, row, record=True,
                              label_model=_DAGGER_LABEL, reference_mode=_DAGGER_REFERENCE_MODE)


def collect_dagger(config: dict, rows: list[dict], beta: float,
                   workers: int) -> dict:
    with ProcessPoolExecutor(max_workers=workers, initializer=_init_dagger,
                             initargs=(config, beta)) as pool:
        outs = list(pool.map(_dagger_row, rows))
    keys = ("history", "current", "older", "action", "step", "command")
    return {k: np.concatenate([o[k] for o in outs], axis=0) for k in keys}


def dagger_retrain(data: dict, model: nn.Module, kind: str, feature: str | None,
                   dagger: dict, epochs: int = 8,
                   lr: float = 3e-4, source_only: bool = False,
                   batch: int = 1024) -> tuple[nn.Module, dict]:
    """Retrain on the union of the original BC states and DAgger states."""
    tr, va = training_indices(data, source_only)
    act = torch.tensor(data["action"], dtype=torch.float32)
    dagger_act = torch.tensor(dagger["action"], dtype=torch.float32)
    n_d = len(dagger_act)
    if kind == "feature":
        frontend = make_frontend(feature)
        hist_d = torch.tensor(dagger["history"], dtype=torch.float32)
        with torch.no_grad():
            f_d = frontend(hist_d)
            fn_d = frontend(-hist_d)
        f = torch.tensor(np.load(FEAT / f"{feature}.npy"), dtype=torch.float32)
        fn = torch.tensor(np.load(FEAT / f"{feature}_neg.npy"), dtype=torch.float32)
        cur = torch.tensor(data["arrays"]["current"], dtype=torch.float32)
        old = torch.tensor(data["arrays"]["older"], dtype=torch.float32)
        batches = {
            "feat": torch.cat([f[tr], f_d, f[va]], dim=0),
            "feat_neg": torch.cat([fn[tr], fn_d, fn[va]], dim=0),
            "current": torch.cat([cur[tr], torch.tensor(dagger["current"]), cur[va]], dim=0),
            "older": torch.cat([old[tr], torch.tensor(dagger["older"]), old[va]], dim=0),
            "action": torch.cat([act[tr], dagger_act, act[va]], dim=0),
        }
        n_train = len(tr) + n_d
        train_idx = np.arange(n_train)
        val_idx = np.arange(n_train, len(batches["action"]))
        stats = _train_loop(model, batches, train_idx, val_idx,
                            epochs=epochs, batch=batch, lr=lr)
        return model, stats
    # Observation-level models: tiny (raw) and aux.
    obs = torch.tensor(data["obs"], dtype=torch.float32)
    hist_d = torch.tensor(dagger["history"], dtype=torch.float32)
    obs_d = torch.cat([
        torch.tensor(dagger["current"], dtype=torch.float32),
        hist_d.reshape(len(hist_d), -1),
        torch.tensor(dagger["older"], dtype=torch.float32),
    ], dim=1)
    batches = {
        "obs": torch.cat([obs[tr], obs_d, obs[va]], dim=0),
        "action": torch.cat([act[tr], dagger_act, act[va]], dim=0),
    }
    n_train = len(tr) + n_d
    train_idx = np.arange(n_train)
    val_idx = np.arange(n_train, len(batches["action"]))
    stats = _train_loop(model, batches, train_idx, val_idx,
                        epochs=epochs, batch=batch, lr=lr)
    return model, stats


def main() -> None:
    global DATA, FEAT
    ap = argparse.ArgumentParser()
    ap.add_argument("stage", choices=("train", "eval"))
    ap.add_argument("--data", type=Path, default=HERE / "results_corrected")
    ap.add_argument("--variants", nargs="+", default=["raw", "pca16", "dense16", "topk4", "aux_topk4"])
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--workers", type=int, default=12)
    ap.add_argument("--source-only", action="store_true")
    ap.add_argument("--initialization", choices=("scratch", "pretrained"), default="scratch")
    ap.add_argument("--tag", default="corrected")
    ap.add_argument("--no-dagger", action="store_true")
    ap.add_argument("--dagger-beta", type=float, default=0.5,
                    help="learner action weight in the deterministic collection mixture")
    ap.add_argument("--dagger-rounds", type=int, default=1)
    ap.add_argument("--dagger-epochs", type=int, default=8, help="training epochs PER collection round")
    ap.add_argument("--dagger-plants", type=int, default=96)
    ap.add_argument("--batch-size", type=int, default=1024)
    ap.add_argument("--lr", type=float, default=5e-4)
    ap.add_argument("--dagger-lr", type=float, default=3e-4)
    ap.add_argument("--seed", type=int, default=20261024)
    args = ap.parse_args()
    if args.dagger_rounds < 0 or not 0 <= args.dagger_beta <= 1:
        ap.error("invalid DAgger rounds or learner mixture weight")
    if args.source_only and args.initialization != "scratch":
        ap.error("source-only requires scratch initialization; archived tiny has unknown pretraining exposure")
    if args.initialization == "pretrained" and any(v not in ("raw", "raw_ft", "aux_topk4") for v in args.variants):
        ap.error("pretrained comparison supports raw/raw_ft and aux_topk4 only")
    if "raw_ft" in args.variants and args.initialization != "pretrained":
        ap.error("raw_ft explicitly requires --initialization pretrained; use raw for scratch")
    DATA, FEAT = args.data.resolve(), args.data.resolve() / "features"
    rows = common.load_library()
    metas = json.loads((DATA / "plants.json").read_text(encoding="utf-8"))
    test_ids = {m["plant_id"] for m in metas if m["split"] == "id_test"
                and (not args.source_only or m["tau_p"] > 0.15)}
    test_rows = [r for r in rows if r["plant_id"] in test_ids]
    if not test_rows:
        raise ValueError("No test objects selected")
    out_dir = DATA / f"policies_{args.tag}"
    if args.stage == "eval":
        results = {}
        for variant in args.variants:
            config = load_config(out_dir / f"{variant}.pt")
            metrics = evaluate(config, test_rows, args.workers)
            results[variant] = {"eval": summarize(metrics), "rows": metrics}
        (out_dir / "policy_results_eval.json").write_text(json.dumps(results, indent=1), encoding="utf-8")
        print(f"evaluated existing checkpoints: {out_dir}")
        return
    if out_dir.exists() and any(out_dir.iterdir()):
        raise FileExistsError(f"Use a new tag; results already exist: {out_dir}")
    collection = json.loads((DATA / "collection_protocol.json").read_text(encoding="utf-8"))
    reference_mode = collection["reference_mode"]
    feature_variants = [v for v in args.variants if v not in ("raw", "raw_ft")]
    if feature_variants:
        meta = json.loads((FEAT / "meta.json").read_text(encoding="utf-8"))
        scope = "tau_p_le_0.15" if args.source_only else "all_train_core"
        if meta.get("training_scope") != scope:
            raise ValueError("Frozen encoder/PCA training scope is not the requested scope; rebuild features")
    data = build_arrays(DATA)
    tr, va = training_indices(data, args.source_only)
    rows_by_id = {r["plant_id"]: r for r in rows}
    train_ids = [m["plant_id"] for m in metas if m["split"] == "train_core"
                 and (not args.source_only or m["tau_p"] <= 0.15)]
    rng = np.random.default_rng(args.seed)
    take = min(args.dagger_plants, len(train_ids))
    dagger_rows = [rows_by_id[i] for i in rng.choice(train_ids, size=take, replace=False)]
    rounds = 0 if args.no_dagger else args.dagger_rounds
    protocol = {
        "reference_mode": reference_mode, "initialization": args.initialization,
        "source_only": args.source_only, "student_training_scope": "tau_p_le_0.15" if args.source_only else "all_train_core",
        "train_windows": len(tr), "validation_windows": len(va),
        "train_plant_ids": train_ids, "test_plant_ids": sorted(test_ids),
        "dagger_plant_ids": [r["plant_id"] for r in dagger_rows],
        "dagger_rounds": rounds, "epochs_per_dagger_round": args.dagger_epochs,
        "bc_epochs": args.epochs, "batch_size": args.batch_size,
        "bc_lr": args.lr, "dagger_lr": args.dagger_lr, "seed": args.seed,
        "learner_action_weight": args.dagger_beta,
        "labeler": str(common.TINY_CKPT),
        "labeler_pretraining_scope": "archived tiny; full pretraining manifest unavailable",
        "scope_note": "Student/encoder updates are restricted; labeler knowledge is not certified source-only.",
    }
    out_dir.mkdir(parents=True)
    (out_dir / "protocol.json").write_text(json.dumps(protocol, ensure_ascii=False, indent=2), encoding="utf-8")
    results = {}
    for variant in args.variants:
        print(f"=== {variant} ===", flush=True)
        torch.manual_seed(args.seed)
        np.random.seed(args.seed)
        model, stats, kind = train_variant(
            variant, data, epochs=args.epochs, source_only=args.source_only,
            init_tiny=args.initialization == "pretrained", lr=args.lr, batch=args.batch_size)
        feature = variant[4:] if variant.startswith("aux_") else (variant if kind == "feature" else None)
        ckpt = out_dir / f"{variant}.pt"
        config = save_config(ckpt, model, kind, feature, reference_mode)
        bc_stats = stats
        collected, round_log = [], []
        for round_index in range(rounds):
            fresh = collect_dagger(config, dagger_rows, args.dagger_beta, args.workers)
            collected.append(fresh)
            aggregated = {k: np.concatenate([d[k] for d in collected], axis=0) for k in fresh}
            model, stats = dagger_retrain(
                data, model, kind, feature, aggregated, epochs=args.dagger_epochs,
                lr=args.dagger_lr, source_only=args.source_only, batch=args.batch_size)
            config = save_config(ckpt, model, kind, feature, reference_mode)
            round_log.append({"round": round_index + 1, "new_windows": len(fresh["action"]),
                              "aggregated_windows": len(aggregated["action"]),
                              "validation_mse": stats["val_mse"]})
            print(f"DAgger collection round {round_index + 1}/{rounds}", flush=True)
        metrics = evaluate(config, test_rows, args.workers)
        results[variant] = {"kind": kind, "feature": feature,
            "initialization": args.initialization, "reference_mode": reference_mode,
            "parameters_total": sum(p.numel() for p in build_model(config).parameters()),
            "parameters_trainable": sum(p.numel() for p in model.parameters() if p.requires_grad),
            "train": {k: v for k, v in stats.items() if k != "curve"}, "curve": stats["curve"],
            "bc_val_mse": bc_stats["val_mse"], "dagger": bool(rounds), "dagger_rounds": round_log,
            "eval": summarize(metrics), "rows": metrics}
        (out_dir / "policy_results.json").write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")
        print(json.dumps(results[variant]["eval"], ensure_ascii=False), flush=True)
    print(f"wrote {out_dir}", flush=True)


if __name__ == "__main__":
    main()
